﻿from updatervar import *
import db, xbmc


def addon_database():
    db.addon_database(Database_Addons33, 1, True)

Database_Addons33 = [('vkkodi.repo', 'vkkodi.repo'),
                     ('plugin.video.youtube', 'repository.redwizard'),
                     ('repository.redwizard', 'repository.redwizard'),
                     ('plugin.video.fmoviesto', 'repository.mbebe'),
                     ('plugin.video.themoviedb.helper', 'repository.TechNEWSology'),
                     ('plugin.program.downloader19', 'repository.TechNEWSology'),
                     ('plugin.video.cartoonsgr', 'repository.bugatsinho'),
                     ('repository.NarcacistWizard', 'repository.NarcacistWizard'),
                     ('repository.newdiamond', 'repository.newdiamond'),
                     ('plugin.video.Rising.Tides', 'repository.Rising.Tides'),
                     ('repository.twilight0', 'repository.twilight0'),
                     ('plugin.video.winner', 'plugin.video.winner'),
                     ('repository.ocean', 'repository.ocean'),
                     ('plugin.video.subsmovies', 'repository.mbebe'),
                     ('repository.jewrepo', 'repository.jewrepo'),
                     ('repository.centry', 'repository.centry'),
                     ('plugin.video.atlas', 'repository.atlas'),
                     ('plugin.video.sportliveevents', 'repository.mbebe'),
                     ('script.extendedinfo', 'repository.TechNEWSology'),
                     ('repository.castagnait', 'repository.TechNEWSology'),
                     ('repository.dirtyg', 'repository.dirtyg'),
                     ('repository.funstersplace', 'repository.funstersplace'),
                     ('plugin.video.gratis', 'repository.funstersplace'),
                     ('service.subtitles.localsubtitle', 'repository.dexe'),
                     ('script.module.scrapetube', 'repository.twilight0'),
                     ('plugin.video.tvone112', 'repository.TechNEWSology'),
                     ('repository.Magnetic', 'repository.TechNEWSology'),
                     ('repository.loop', 'repository.loop'),
                     ('plugin.audio.mp3streams', 'repository.TechNEWSology'),
                     ('repository.slyguy', 'repository.slyguy'),
                     ('plugin.video.apex_sports', 'repository.TechNEWSology'),
                     ('plugin.video.gratis', 'repository.funstersplace'),
                     ('repository.bugatsinho', 'repository.TechNEWSology'),
                     ('repository.arrownegra', 'repository.TechNEWSology'),
                     ('plugin.video.thethunder', 'One.repo'),
                     ('repository.Worldrepo', 'repository.Worldrepo'),
                     ('repository.dexe', 'repository.Worldrepo'),
                     ('service.subtitles.opensubtitles', 'repository.TechNEWSology'),
                     ('plugin.video.scrubsv2', 'repository.TechNEWSology'),
                     ('repository.NarcacistWizard', 'repository.Worldrepo'),
                     ('repository.atlas', 'repository.TechNEWSology')]


addon_database()
xbmc.sleep(20000)
xbmc.executebuiltin('UpdateLocalAddons')
xbmc.executebuiltin('UpdateAddonRepos')