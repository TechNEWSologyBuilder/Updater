﻿import os, glob, xbmc, xbmcvfs, xbmcgui, shutil

#BG               = xbmcgui.DialogProgressBG()
addons_file      = xbmcvfs.translatePath('special://home/addons')
addons_path      = os.path.join(xbmcvfs.translatePath('special://home/addons/'))
addons_data_path = [xbmcvfs.translatePath('special://home/addons'), xbmcvfs.translatePath('special://home/userdata/addon_data')]

delete_addon_path = ['repository.host505']


delete_files = ['script.hideosd', 'plugin.program.G.K.N.Wizard', 'plugin.video.PLsportowo', 'repository.slam19',
                'repository.DejaVu', 'plugin.video.tide', 'plugin.video.sportliveevents','script.theoath.metadata',
                'plugin.video.centrysports', 'repository.host505', 'script.theoath.artwork','plugin.video.subsmovies',
                'repository.diamond-wizard-repo-k19', 'repository.arrownegra', 'slyguy.dependencies', 'script.module.slyguy',
                'plugin.video.themoviebaynet', 'repository.tikipeter', 'script.module.oathscrapers', 'plugin.video.theoath',
                'plugin.video.crackle', 'repository.diamond-wizard-repo', 'repository.centry', 'repository.ocean', 'plugin.video.fmoviesto',
                'plugin.video.gratis', 'plugin.video.sportscentral', 'plugin.video.thethunder',
                'plugin.video.tvseriesvideo', 'repository.funstersplace', 'repository.NarcacistWizard']

#                Skinshortcuts_path, Skinshortcuts_path2, UpdaterMatrix_path, UpdaterMatrix_path3, UpdaterMatrix_path2,
#                UpdaterMatrix_path4, UpdaterMatrix_path5, UpdaterMatrix_path7, UpdaterMatrix_path9, UpdaterMatrix_path11,
#                UpdaterMatrix_path12, UpdaterMatrix_path14, UpdaterMatrix_path19, UpdaterMatrix_path20, UpdaterMatrix_path22,
#                UpdaterMatrix_path25, UpdaterMatrix_path26, UpdaterMatrix_path27, UpdaterMatrix_path28, UpdaterMatrix_path29,
#                UpdaterMatrix_path6, UpdaterMatrix_path8, UpdaterMatrix_path10, UpdaterMatrix_path13, UpdaterMatrix_path15,
#                UpdaterMatrix_path21, UpdaterMatrix_path23, UpdaterMatrix_path24, UpdaterMatrix_path31, UpdaterMatrix_path32,
#                UpdaterMatrix_path30]


def check_del_dir():
    del_dir_addon_path()
    for path_list in delete_files:
        if os.path.exists(addons_path + '%s' % path_list) or os.path.exists('%s' % path_list):
            path_list = '[B][COLOR=red]%s[/COLOR][/B]' % path_list
            del_dir()
        #    BG.create('[B]Διαγραφή αρχείων...[/B]', path_list)
        #    BG.update(28, '[B]Διαγραφή αρχείων...[/B]', path_list)
            xbmc.sleep(3000)
        #    BG.close()


def del_dir_addon_path():
        for rr in delete_addon_path:
            dir_list = glob.iglob(os.path.join(addons_file, rr))
            for path in dir_list:
                if os.path.isdir(path):
                    shutil.rmtree(path)


def del_dir():#addons #addon_data
    for ad in addons_data_path:
     for rr in delete_files:
       dir_list = glob.iglob(os.path.join(ad, rr))
       for path in dir_list:
           if os.path.isdir(path):
               shutil.rmtree(path)
           if os.path.isfile(path):
              os.remove(path)


check_del_dir()
