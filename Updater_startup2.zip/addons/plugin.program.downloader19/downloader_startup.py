﻿import os, glob, xbmc, xbmcgui, xbmcvfs, xbmcaddon, shutil
from updatervar import *
from resources.lib.GUIcontrol import txt_updater
from resources.lib.modules import db, addonsEnable
from resources.lib.modules.addonsEnable import enable_addons
from resources.lib.GUIcontrol.txt_updater import get_skinshortcutsversion

skinshortcuts_version = get_skinshortcutsversion()



Database_Addons33 = [('plugin.video.fmoviesto', 'repository.mbebe'),('plugin.video.themoviedb.helper', 'repository.TechNEWSology'),
                     ('plugin.program.downloader19', 'repository.TechNEWSology'), ('plugin.video.cartoonsgr', 'repository.bugatsinho'),
                     ('repository.NarcacistWizard', 'repository.NarcacistWizard'), ('repository.newdiamond', 'repository.newdiamond'),
                     ('plugin.video.Rising.Tides', 'repository.Rising.Tides'), ('script.extendedinfo', 'repository.TechNEWSology'),
                     ('repository.diamond-wizard-repo-k19', 'repository.diamond-wizard-repo-k19'), ('repository.loop', 'repository.loop'),
                     ('plugin.video.winner', 'plugin.video.winner'), ('repository.ocean', 'repository.ocean'), ('vkkodi.repo', 'vkkodi.repo'),
                     ('plugin.video.subsmovies', 'repository.mbebe'), ('repository.jewrepo', 'repository.jewrepo')]

addons_list_installation = ['repository.jewrepo', 'plugin.video.themoviedb.helper', 'plugin.video.skylinecctv', 'plugin.program.autowidget',
                           'plugin.video.live.streamspro', 'plugin.program.downloader19', 'context.subtitles.gr',
                           'service.subtitles.opensubtitles_by_opensubtitles', 'service.subtitles.localsubtitle',
                           'service.subtitles.greeksubs', 'plugin.video.playlistloader', 'context.themoviedb.helper',
                           'plugin.video.tvone1112', 'repository.vstream', 'repository.thecrew', 'context.trailer.mod',
                           'plugin.video.tvone111', 'plugin.video.sporthdme', 'plugin.video.cartoonsgr',
                           'repository.NarcacistWizard', 'repository.Rising.Tides', 'plugin.video.subsmovies',
                           'plugin.video.microjen', 'plugin.video.atlas', 'plugin.video.scrubsv2']

delete_addons = ['repository.slam19', 'plugin.video.themoviedb.helper', UpdaterMatrix_path3, UpdaterMatrix_path4, UpdaterMatrix_path5, UpdaterMatrix_path7, UpdaterMatrix_path9,
                 UpdaterMatrix_path11, UpdaterMatrix_path12, UpdaterMatrix_path14, Skinshortcuts_path, Skinshortcuts_path2]


def Updater_Matrix():
    BG.create(Dialog_U1, Dialog_U2)

    xbmc.sleep(5000)
    BG.update(5, Dialog_U1, 'Διαγραφή αχρείαστων αρχείων...')
    del_dir()
    BG.update(15, Dialog_U1, Dialog_U6)
    xbmc.sleep(1000)
    BG.update(25, Dialog_U1, Dialog_U6)

    xbmc.sleep(1000)
    db.addon_database(Database_Addons33, 1, True)
    xbmc.sleep(5000)
    BG.update(30, Dialog_U1, 'Εισαγωγή αποθετηρίων στο Database/Addons33...')
#    installAddon()
    addonsEnable.enable_addons()

#    if os.path.exists(addons_path + 'repository.slam19') or os.path.exists(UpdaterMatrix_path3) or os.path.exists(UpdaterMatrix_path4) or os.path.exists(UpdaterMatrix_path5) or os.path.exists(UpdaterMatrix_path7) or os.path.exists(UpdaterMatrix_path9) or os.path.exists(UpdaterMatrix_path11) or os.path.exists(UpdaterMatrix_path12) or os.path.exists(UpdaterMatrix_path14):
#        del_dir()
#        BG.update(33, Dialog_U1, 'Διαγραφή αχρείαστων αρχείων...')
#        xbmc.sleep(10000)

    if not os.path.exists(UpdaterMatrix_path8):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_8)
        xbmc.sleep(5000)
        BG.update(36, Dialog_U1, 'Εισαγωγή repository.newdiamond - script.extendedinfo...')

    if not os.path.exists(UpdaterMatrix_path):
        xbmc.executebuiltin(UpdaterMatrix_1)
        xbmc.sleep(1000)

#    BG.update(36, Dialog_U1, Dialog_U2)

    if not os.path.exists(UpdaterMatrix_path2):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_2)

    BG.update(45, Dialog_U1, Dialog_U2)

    if not os.path.exists(UpdaterMatrix_path6):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_6)
        xbmc.sleep(5000)
    BG.update(50, Dialog_U1, Dialog_U2)

    if not os.path.exists(UpdaterMatrix_path15):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_15)
        BG.update(60, Dialog_U1, 'Εισαγωγή repository.loop - repository.ocean')

    xbmc.sleep(5000)
#    addonsEnable.enable_addons()
#    BG.update(75, Dialog_U1, 'Ενεργοποίηση πρόσθετων...')
    xbmc.sleep(10000)
#    installAddon()
    BG.update(80, Dialog_U1, Dialog_U6)

    if not os.path.exists(UpdaterMatrix_path10):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_10)
        xbmc.sleep(5000)
        BG.update(82, Dialog_U1, 'Προσθήκες-Διορθώσεις στα xml του skin...')
        xbmc.sleep(10000)

    if not os.path.exists(UpdaterMatrix_path13):
        xbmc.sleep(5000)
        xbmc.executebuiltin(UpdaterMatrix_13)
        xbmc.sleep(10000)
        BG.update(88, Dialog_U1, 'Εισαγωγή νέων διακομιστών του PvrStalker...')
        xbmc.sleep(10000)
        BG.update(90, Dialog_U1, 'Εισαγωγή αποθετηρίων...')
        xbmc.sleep(15000)
        BG.update(92, Dialog_U1, 'repository.Vikings - repository.diamond-k19...')

    if not os.path.exists(UpdaterMatrix_path19):
        xbmc.sleep(3000)
        xbmc.executebuiltin(UpdaterMatrix_19)
        xbmc.sleep(5000)
        BG.update(93, Dialog_U1, 'Προσθήκες-Διορθώσεις στα xml του skin ...')
        xbmc.sleep(4000)
        BG.update(95, Dialog_U1, 'Προσθήκες-Διορθώσεις στα xml του skin ...')
#    xbmc.executebuiltin('UpdateAddonRepos')

    xbmc.sleep(5000)
    BG.update(88, Dialog_U1, 'Εγκατάσταση πρόσθετων...')
    installAddon()
    xbmc.sleep(5000)
    BG.update(93, Dialog_U1, 'Ενεργοποίηση πρόσθετων...')
    addonsEnable.enable_addons()


    if skinshortcuts_version > int(setting('skinshortcutsversion')):
        xbmc.executebuiltin(skinshortcuts_menu)
        xbmc.sleep(10000)
        BG.update(96, Dialog_U1, 'Εισαγωγή xml αρχείων του script.skinshortcuts...')
        xbmc.sleep(5000)
    #    addon_themoviedb       = xbmcaddon.Addon('plugin.video.themoviedb.helper')
    #    setting_themoviedb     = addon_themoviedb.getSetting
    #    setting_set_themoviedb = addon_themoviedb.setSetting
    #    if setting_themoviedb('widgets_nextpage')=='false':
    #        setting_set_themoviedb('widgets_nextpage', 'true')
    #        xbmc.sleep(3000)
    #        BG.update(99, Dialog_U1, 'Ενεργοποίηση next page των widgets')
    #        xbmc.sleep(5000)
    #        BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
    #        xbmc.sleep(8000)
    #        BG.update(100, Dialog_U4, Dialog_U5)
    #        xbmc.executebuiltin("ReloadSkin()")
    #    else:
    #        xbmc.sleep(5000)
        BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
        xbmc.sleep(8000)
        BG.update(100, Dialog_U4, Dialog_U5)
        xbmc.executebuiltin("ReloadSkin()")
    setting_set('skinshortcutsversion', str(skinshortcuts_version))

#    if setting_themoviedb('widgets_nextpage')=='false':
#        BG.update(97, Dialog_U1, 'Ενεργοποίηση next page των widgets')
#        setting_set_themoviedb('widgets_nextpage', 'true')
#        xbmc.sleep(3000)
#        BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
#        xbmc.sleep(5000)
#        BG.update(100, Dialog_U4, Dialog_U5)
#        xbmc.sleep(2000)
#        xbmc.executebuiltin("ReloadSkin()")


    xbmc.sleep(5000)
    installAddon()


    BG.update(100, Dialog_U4, Dialog_U5)
#    dialog.notification(Dialog_U7, Dialog_U5, icon_Build, sound=False)
    xbmc.sleep(5000)
    BG.update(100, Dialog_U4, Dialog_U5)
    BG.close()
    xbmcvfs.delete(downloader_startup_delete)



def installAddon():
    for addon_id in addons_list_installation:
      xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
      xbmc.sleep(100)
      xbmc.executebuiltin('SendClick(11)')
      xbmc.sleep(100)


def del_dir():
    for ad in addons_data_path:
     for rr in delete_addons:
       dir_list = glob.iglob(os.path.join(ad, rr))
       for path in dir_list:
           if os.path.isdir(path):
               shutil.rmtree(path)
           if os.path.isfile(path):
              os.remove(path)

Updater_Matrix()
