﻿import xbmc, xbmcgui


def t_menu():
    funcs = (click1, click2, click3, click4, click5, click6, click7, click8, click9, click10, click11, click12, click13, click14, click15,
             click16, click17, click18, click19, click20)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                                                    ~ Εργαλεία ~[/COLOR][/B]',
['[B][COLOR=white]             Επαναφορά Ενημέρωσης Μενού [COLOR=orange](Skinshortcuts-Xml Skin)[/COLOR][/B]',
 '[B][COLOR=lime]                           Ενεργοποίηση [COLOR=white]όλων των πρόσθετων[/COLOR][/B]',
# '[B][COLOR=white]                   Αν δεν εμφανίζονται τα Widgets ή τα Εικονίδια ...[/COLOR][/B]',
 '[B][COLOR=white]                       Advanced Settings [COLOR=orange]TechNEWSology Build[/COLOR][/B]',
 '[B][COLOR=white]                                            Ρυθμίσεις [COLOR lime]ResolveURL[/COLOR][/B]',
 '[B][COLOR=white]                                         Επιλογή Api Key [COLOR red]YouTube[/COLOR][/B]',
# '[B][COLOR=white]                                   Έληξε η Συνδρομή μας [COLOR lime]AllDebrid ...[/COLOR][/B]',
# '[B][COLOR=white]                             Έληξε η Συνδρομή μας [COLOR lime]PremiumizeMe ...[/COLOR][/B]',
 '[B][COLOR=white]                                            Εξουσιοδότηση [COLOR lime]Trakt ...[/COLOR][/B]',
 '[B][COLOR=white]                                    Αντίγραφο ασφαλείας Build[/COLOR][/B]',
 '[B][COLOR=lime]                                      Καθαρή Εγκατάσταση Build[/COLOR][/B]',
 '[B][COLOR=white]                        Επαναφορά απο αντίγραφο ασφαλείας Build[/COLOR][/B]',
 '[B][COLOR=orange]                                 TechNEWSology Updater - Tools[/COLOR][/B]',
 '[B][COLOR=white]                          Έγκριση του λογαριασμού μου [COLOR lime]RealDebrid ...[/COLOR][/B]',
 '[B][COLOR=white]                            Έγκριση του λογαριασμού μου [COLOR lime]AllDebrid ...[/COLOR][/B]',
 '[B][COLOR=white]                       Έγκριση του λογαριασμού μου [COLOR lime]PremiumizeMe ...[/COLOR][/B]',
 '[B][COLOR=white]                                      Εγκατάσταση Binary Addons[/COLOR][/B]',
 '[B][COLOR=red]                                            Διαγραφή[COLOR=white] PVR Stalker[/COLOR][/B]',
 '[B][COLOR=lime]                                    Καθαρισμός[COLOR=white] παρόχων-Cache[/COLOR][/B]',
# '[B][COLOR=white]                                                    Save Data[/COLOR][/B]',
# '[B][COLOR=white]                                                   Reload Skin[/COLOR][/B]',
# '[B][COLOR=white]                                         Enable/Disable Addons[/COLOR][/B]',
 '[B][COLOR=white]                                                    Speed Test[/COLOR][/B]',
 '[B][COLOR=white]                                              Εργαλεία AliveGR[/COLOR][/B]',
 '[B][COLOR=orange]   Απενεργοποίηση [COLOR=white]αυτόματων ενημερώσεων του Downloader Startup[/COLOR][/B]',
 '[B][COLOR=lime]     Ενεργοποίηση [COLOR=white]αυτόματων ενημερώσεων του Downloader Startup[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-20]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click1():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgithub.com%2FTechNEWSologyBuilder%2FUpdater%2Fraw%2Fmain%2FBackgrounds_With_Widgets.zip&mode=9)')
    xbmcgui.Dialog().notification('[B][COLOR orange]TechNEWSology[/COLOR][/B]', '[B][COLOR white]Αναμονή... προς ολοκλήρωση διαδικασίας![/COLOR][/B]', '', sound=False)
    xbmc.sleep(5000)
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https%3A%2F%2Fgithub.com%2FTechNEWSologyBuilder%2FUpdater%2Fraw%2Fmain%2FXmlSkin_startup.zip&mode=9)')
    xbmc.sleep(10000)
    xbmc.executebuiltin("LoadProfile(Master user)")

def click2():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=25,return)')

#def click4():
#    xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/FixWidget.py)')

#def click6():
#    xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/AdvancedSettings.py)')

def click3():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=4,return)')

def click4():
    import resolveurl
    resolveurl.display_settings()

def click5():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19/?mode=1,return)')

#def click7():
#    xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/ResolverOffAllDebrid.py)')

#def click8():
#    xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/ResolverOffPremiumizeMe.py)')

def click6():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.video.scrubsv2/?action=auth_trakt)')

def click7():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=18,return)')

def click8():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19/?mode=12,return)')

def click9():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19/?mode=19,return)')

def click10():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19,return)')

def click11():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)')

def click12():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_ad)')

def click13():
    xbmc.executebuiltin('RunPlugin(plugin://script.module.resolveurl/?mode=auth_pm)')

def click14():
    xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/installer_binary.py)')

def click15():
    xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/StalkerDelete.py")')

#def click15():
#    xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/indigoDel.py)')

def click16():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=23)')
    xbmc.sleep(8000)
    xbmc.executebuiltin('SendClick(11)')

def click17():
    xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.downloader19/?url=&mode=31,return)')

def click18():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.AliveGR/?action=settings,return)')

def click19():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=29,return)')

def click20():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=30,return)')


t_menu()
