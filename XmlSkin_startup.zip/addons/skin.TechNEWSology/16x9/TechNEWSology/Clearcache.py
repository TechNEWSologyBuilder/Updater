import xbmc

def clearcache():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=clearcache)')
    xbmc.sleep(3500)
    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
        xbmc.sleep(600)
        xbmc.executebuiltin('SendClick(11)')
        xbmc.sleep(1500)
        xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=23)')
        xbmc.sleep(8000)
        xbmc.executebuiltin('SendClick(11)')
clearcache()
