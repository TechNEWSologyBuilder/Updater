import xbmc, xbmcgui

def autoadvanced():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TechNEWSology[/COLOR][/B]', '[COLOR white]Για να επιτύχουμε καλύτερο streaming του Βίντεο, αλλάζουμε την τιμή στο Video Cache size από αυτήν που έχει μπαίνοντας στο *Advanced Settings Configurator* σε 120 μέχρι 150! Μετά πατάμε Write File και κάνουμε επανεκκίνηση το Kodi για να καταχωρηθούν οι αλλαγές! [B][COLOR red]Tip:[/COLOR][/B] [COLOR white]Για καλύτερο buffering πατάμε παύση [COLOR lime](||)[COLOR white] στην Έναρξη του Βίντεο για μερικά λεπτά.[/COLOR]',
                                        nolabel='[COLOR red]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Advanced Settings[/COLOR]')

        if choice == 1: xbmc.executebuiltin('RunPlugin(plugin://plugin.program.G.K.N.Wizard/?mode=autoadvanced)')

autoadvanced()
