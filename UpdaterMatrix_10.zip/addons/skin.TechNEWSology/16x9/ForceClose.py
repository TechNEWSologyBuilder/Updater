import os, xbmcgui

def killkodi():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TechNEWSology[/COLOR][/B]', '[COLOR white]Το Kodi θα κλείσει άμεσα...[CR]Θέλετε να συνεχίσετε?[/COLOR]',
                                        nolabel='[COLOR white]Όχι[/COLOR]',yeslabel='[COLOR white]Ναι[/COLOR]')
        if choice == 1: os._exit(1)

killkodi()