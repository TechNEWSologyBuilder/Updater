﻿from updatervar import *

addons_list_installation = ['repository.redwizard', 'plugin.program.autowidget', 'repository.atlas', 'One.repo',
                           'plugin.video.live.streamspro', 'plugin.program.downloader19', 'service.subtitles.opensubtitles-com',
                           'service.subtitles.opensubtitles_by_opensubtitles', 'service.subtitles.localsubtitle', 'plugin.video.macvod',
                           'service.subtitles.greeksubs', 'plugin.video.playlistloader', 'context.themoviedb.helper',
                           'plugin.video.tvone1112', 'repository.vstream', 'repository.thecrew', 'context.trailer.mod',
                           'plugin.video.tvone111', 'plugin.video.sporthdme', 'plugin.video.tvone112', 'plugin.video.atlas',
                           'repository.Rising.Tides', 'repository.slyguy', 'plugin.video.blacklodge', 'repository.rays.files',
                           'plugin.video.microjen', 'plugin.video.scrubsv2', 'service.subtitles.All_Subs']


def check_addons_list():
    if not exists(addons_path + 'plugin.video.blacklodge'):
        xbmc.executebuiltin(SRV + 'Settings_Blacklodge.zip&mode=9)')
    for addons_list in addons_list_installation:
        if not exists(addons_path + '%s' % addons_list):
            addons_list = '[B][COLOR=lime]%s[/COLOR][/B]' % addons_list
            xbmc.sleep(1000)
            installAddon()
        #    BG.create(Dialog_U1, addons_list)
        #    BG.update(70, Dialog_U1, addons_list)
            xbmc.sleep(14000)
        #    BG.close()

def installAddon():
    for addon_id in addons_list_installation:
      xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
      xbmc.sleep(200)
      xbmc.executebuiltin('SendClick(11)')
      xbmc.sleep(200)

check_addons_list()
