﻿from updatervar import *

addons_list_installation = ['repository.redwizard', 'repository.jewrepo', 'plugin.video.skylinecctv', 'plugin.program.autowidget', 'repository.atlas',
                           'plugin.video.live.streamspro', 'plugin.program.downloader19', 'context.subtitles.gr', 'service.subtitles.opensubtitles-com',
                           'service.subtitles.opensubtitles_by_opensubtitles', 'service.subtitles.localsubtitle', 'plugin.video.macvod',
                           'service.subtitles.greeksubs', 'plugin.video.playlistloader', 'context.themoviedb.helper', 'One.repo',
                           'plugin.video.tvone1112', 'repository.vstream', 'repository.thecrew', 'context.trailer.mod',
                           'plugin.video.tvone111', 'plugin.video.sporthdme', 'plugin.video.cartoonsgr', 'plugin.video.tvone112',
                           'repository.NarcacistWizard', 'repository.Rising.Tides', 'repository.slyguy', 'repository.funstersplace',
                           'plugin.video.microjen', 'plugin.video.atlas', 'plugin.video.scrubsv2', 'plugin.video.blacklodge', 'service.subtitles.All_Subs']


def check_addons_list():
    if not exists(addons_path + 'plugin.video.blacklodge'):
        xbmc.executebuiltin(SRV + 'Settings_Blacklodge.zip&mode=9)')
    for addons_list in addons_list_installation:
        if not exists(addons_path + '%s' % addons_list):
            addons_list = '[B][COLOR=lime]%s[/COLOR][/B]' % addons_list
            xbmc.sleep(1000)
            installAddon()
        #    BG.create(Dialog_U1, addons_list)
        #    BG.update(70, Dialog_U1, addons_list)
            xbmc.sleep(14000)
        #    BG.close()

def installAddon():
    for addon_id in addons_list_installation:
      xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
      xbmc.sleep(200)
      xbmc.executebuiltin('SendClick(11)')
      xbmc.sleep(200)

check_addons_list()
