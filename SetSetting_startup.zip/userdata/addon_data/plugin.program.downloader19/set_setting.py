﻿import xbmc, xbmcaddon, xbmcvfs
from updatervar import *

Dialog_U1                 = '[B]Αναμονή για ολοκλήρωση ενημέρωσης[/B]'
Dialog_U4                 = '[B]Ολοκληρώθηκε με επιτυχία[/B]'

def set_setting():
    ###  ScrubsV2   ###
    BG.create(Dialog_U1, 'Εναρξη ενημέρωσης ρυθμίσεων...')
    xbmc.sleep(1000)
    addon_scrubsv2       = xbmcaddon.Addon('plugin.video.scrubsv2')
    setting_scrubsv2     = addon_scrubsv2.getSetting
    setting_set_scrubsv2 = addon_scrubsv2.setSetting
    if setting_scrubsv2('subtitles')=='false':
        xbmc.sleep(1000)
        setting_set_scrubsv2('subtitles', 'true')
        BG.update(5, Dialog_U1, 'Ενεργοποίηση υποτίτλων ScrubsV2...')
        xbmc.sleep(2000)
        setting_set_scrubsv2('subtitles.lang.1', 'Greek')
        BG.update(15, Dialog_U1, 'Επιλογή κύριας γλώσσας υποτίτλων σε Ελληνικά...')
        xbmc.sleep(2000)


    ###  Atlas   ###
#    BG.update(20, Dialog_U1, 'Ενημέρωσης ρυθμίσεων...')
#    addon_atlas       = xbmcaddon.Addon('plugin.video.atlas')
#    setting_atlas     = addon_atlas.getSetting
#    setting_set_atlas = addon_atlas.setSetting
#    if not setting_atlas('movie-view')=='MyFlix':
#        xbmc.sleep(1000)
#        setting_set_atlas('movie-view', 'MyFlix')
#        BG.update(25, Dialog_U1, 'Movie view επιλογή -MyFlix-...')
#        xbmc.sleep(2000)


    ###  Homelander   ###
    if os.path.exists(xbmcvfs.translatePath('special://home/addons/plugin.video.gratis')):
        addon_homelander     = xbmcaddon.Addon('plugin.video.homelander')
        setting_homelander     = addon_homelander.getSetting
        setting_set_homelander = addon_homelander.setSetting
        BG.update(30, Dialog_U1, 'Ενημέρωσης ρυθμίσεων...')

        if setting_homelander('subtitles')=='false':
            xbmc.sleep(1000)
            setting_set_homelander('subtitles', 'true')
            BG.update(33, Dialog_U1, 'Ενεργοποίηση υποτίτλων Homelander...')
            xbmc.sleep(2000)
            setting_set_homelander('subtitles.lang.1', 'Greek')
            setting_set_homelander('subtitles.lang.2', 'English')
            BG.update(39, Dialog_U1, 'Επιλογή κύριας γλώσσας υποτίτλων σε Ελληνικά...')
            xbmc.sleep(2000)
        if setting_homelander('providers.lang')=='English':
            xbmc.sleep(1000)
            setting_set_homelander('providers.lang', 'Greek+English')
            BG.update(45, Dialog_U1, 'Επιλογή παρόχων σε Greek+English...')
            xbmc.sleep(2000)

    ###  TheMoviedb   ###
    BG.update(50, Dialog_U1, 'Ενημέρωσης ρυθμίσεων...')
    addon_themoviedb       = xbmcaddon.Addon('plugin.video.themoviedb.helper')
    setting_themoviedb     = addon_themoviedb.getSetting
    setting_set_themoviedb = addon_themoviedb.setSetting
    if setting_themoviedb('widgets_nextpage')=='false':
        BG.update(52, Dialog_U1, 'Ενεργοποίηση next page των widgets')
        setting_set_themoviedb('widgets_nextpage', 'true')
        xbmc.sleep(3000)
        if setting_themoviedb('language')=='15' or setting_themoviedb('language')=='18':
            BG.update(64, Dialog_U1, 'Αλλαγή γλώσσας (Gr) TheMovieDb...')
            setting_set_themoviedb('language', '12')
            xbmc.sleep(3000)
            BG.update(88, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
            xbmc.sleep(5000)
            BG.update(100, Dialog_U4, Dialog_U5)
            xbmc.sleep(2000)
            xbmc.executebuiltin("ReloadSkin()")
        else:
            BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
            xbmc.sleep(5000)
            BG.update(100, Dialog_U4, Dialog_U5)
            xbmc.sleep(2000)
            xbmc.executebuiltin("ReloadSkin()")
    BG.update(80, Dialog_U1, 'Ενημέρωσης ρυθμίσεων...')
    if setting_themoviedb('language')=='15' or setting_themoviedb('language')=='18':
        xbmc.sleep(1000)
        setting_set_themoviedb('language', '12')
        BG.update(88, Dialog_U1, 'Αλλαγή γλώσσας (Gr) TheMovieDb...')
        xbmc.sleep(3000)
        BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
        xbmc.sleep(5000)
        BG.update(100, Dialog_U4, Dialog_U5)
        xbmc.sleep(2000)
        xbmc.executebuiltin("ReloadSkin()")
#    else:
#        if skinshortcuts_version > int(setting('skinshortcutsversion')):
#            xbmc.sleep(5000)
#            BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
#            xbmc.sleep(8000)
#            BG.update(100, Dialog_U4, Dialog_U5)
    BG.update(100, Dialog_U4, Dialog_U5)
    xbmc.sleep(1000)
    BG.close()
#            xbmc.executebuiltin("ReloadSkin()")

set_setting()
