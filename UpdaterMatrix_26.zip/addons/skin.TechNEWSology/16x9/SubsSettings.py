﻿import xbmc

def subsettings():
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("ActivateWindowAndFocus(Playersettings, -95,)")
    xbmc.executebuiltin("Action(Pause)")
    while xbmc.getCondVisibility("Window.IsVisible(playersettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

subsettings()
