﻿import os, glob, xbmc, xbmcgui, xbmcvfs, xbmcaddon, shutil
from updatervar import *
from resources.lib.GUIcontrol import txt_updater
from resources.lib.modules import db, addonsEnable
from resources.lib.modules.addonsEnable import enable_addons
from resources.lib.GUIcontrol.txt_updater import get_skinshortcutsversion, get_addonsrepos

skinshortcuts_version = get_skinshortcutsversion()
addons_repos_version = get_addonsrepos()
exists = os.path.exists

Database_Addons33 = [('plugin.video.fmoviesto', 'repository.mbebe'),('plugin.video.themoviedb.helper', 'repository.TechNEWSology'),
                     ('plugin.program.downloader19', 'repository.TechNEWSology'), ('plugin.video.cartoonsgr', 'repository.bugatsinho'),
                     ('repository.NarcacistWizard', 'repository.NarcacistWizard'), ('repository.newdiamond', 'repository.newdiamond'),
                     ('plugin.video.Rising.Tides', 'repository.Rising.Tides'), ('repository.twilight0', 'repository.twilight0'),
                     ('repository.diamond-wizard-repo-k19', 'repository.diamond-wizard-repo-k19'), ('repository.loop', 'repository.loop'),
                     ('plugin.video.winner', 'plugin.video.winner'), ('repository.ocean', 'repository.ocean'), ('vkkodi.repo', 'vkkodi.repo'),
                     ('plugin.video.subsmovies', 'repository.mbebe'), ('repository.jewrepo', 'repository.jewrepo'), ('repository.centry', 'repository.centry'),
                     ('plugin.video.atlas', 'repository.atlas'), ('plugin.video.atlas', 'repository.atlas'), ('plugin.video.sportliveevents', 'repository.mbebe'),
                     ('script.extendedinfo', 'repository.TechNEWSology'), ('repository.castagnait', 'repository.TechNEWSology'),
                     ('repository.arrownegra', 'repository.arrownegra'), ('repository.dexe', 'repository.dexe'),
                     ('rrepository.dirtyg', 'repository.dirtyg'), ('repository.roooar', 'repository.roooar'),
                     ('script.module.scrapetube', 'repository.twilight0'), ('plugin.video.tvone112', 'repository.TechNEWSology')]

addons_list_installation = ['repository.jewrepo', 'repository.centry', 'plugin.video.skylinecctv', 'plugin.program.autowidget', 'repository.atlas',
                           'plugin.video.live.streamspro', 'plugin.program.downloader19', 'context.subtitles.gr', 'plugin.video.tvseriesvideo',
                           'service.subtitles.opensubtitles_by_opensubtitles', 'service.subtitles.localsubtitle', 'plugin.video.macvod',
                           'service.subtitles.greeksubs', 'plugin.video.playlistloader', 'context.themoviedb.helper',
                           'plugin.video.tvone1112', 'repository.vstream', 'repository.thecrew', 'context.trailer.mod',
                           'plugin.video.tvone111', 'plugin.video.sporthdme', 'plugin.video.cartoonsgr', 'plugin.video.tvone112',
                           'repository.NarcacistWizard', 'repository.Rising.Tides', 'plugin.video.subsmovies', 'plugin.video.gratis',
                           'plugin.video.microjen', 'plugin.video.atlas', 'plugin.video.scrubsv2', 'plugin.video.homelander', 'plugin.video.duffyou']

delete_files = ['repository.slam19', 'repository.diamond-wizard-repo', 'repository.diamond-wizard-repo-k19', 'repository.host505', 'repository.DejaVu',
                'plugin.video.themoviebaynet', 'repository.tikipeter', 'script.theoath.artwork', 'script.module.oathscrapers', 'plugin.video.theoath',
                'script.theoath.metadata',
                Skinshortcuts_path, Skinshortcuts_path2, UpdaterMatrix_path, UpdaterMatrix_path3,
                UpdaterMatrix_path4, UpdaterMatrix_path5, UpdaterMatrix_path7, UpdaterMatrix_path9, UpdaterMatrix_path11,
                UpdaterMatrix_path12, UpdaterMatrix_path14, UpdaterMatrix_path19, UpdaterMatrix_path20, UpdaterMatrix_path22,
                UpdaterMatrix_path25, UpdaterMatrix_path26, UpdaterMatrix_path27, UpdaterMatrix_path28, UpdaterMatrix_path29,
                UpdaterMatrix_path30, UpdaterMatrix_path33]

def Updater_Matrix():
    BG.create(Dialog_U1, Dialog_U2)
    xbmc.sleep(500)
    BG.update(5, Dialog_U1, Dialog_U6)
    xbmc.sleep(1000)
    BG.update(15, Dialog_U1, Dialog_U6)
    check_addons_list()
    check_del_dir()
    xbmc.sleep(5000)

    if not exists(UpdaterMatrix_path8):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_8)
        xbmc.sleep(5000)
        BG.update(36, Dialog_U1, 'Εισαγωγή repository.newdiamond - script.extendedinfo...')

    if not exists(UpdaterMatrix_path6):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_6)
        xbmc.sleep(5000)
    BG.update(50, Dialog_U1, Dialog_U2)


    if not exists(UpdaterMatrix_path2):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_2)
        BG.update(52, Dialog_U1, 'Εισαγωγή αποθετηρίων...')
        xbmc.sleep(5000)
        BG.update(53, Dialog_U1, 'repository.jewrepo...')
        xbmc.sleep(1000)
        BG.update(55, Dialog_U1, 'repository.arrownegra...')
        xbmc.sleep(1000)
        BG.update(56, Dialog_U1, 'repository.dirtyg...')
        xbmc.sleep(1000)
        BG.update(57, Dialog_U1, 'repository.roooar...')
        xbmc.sleep(1000)
        BG.update(58, Dialog_U1, 'repository.dexe...')
        xbmc.sleep(1000)


    if not exists(UpdaterMatrix_path15):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_15)
        BG.update(60, Dialog_U1, 'Εισαγωγή repository.loop - repository.ocean')

    xbmc.sleep(3000)
 #   BG.update(75, Dialog_U1, 'Έλεγχος αποθετηρίων στο Database/Addons33...')
 #   xbmc.sleep(3000)

    db.addon_database(Database_Addons33, 1, True)
    BG.update(77, Dialog_U1, 'Έλεγχος για νέες ενημερώσεις...')
    xbmc.sleep(5000)

    if not exists(UpdaterMatrix_path10):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_10)
        xbmc.sleep(5000)
        BG.update(79, Dialog_U1, 'Προσθήκες-Διορθώσεις στα xml του skin...')
        xbmc.sleep(10000)

    if not exists(UpdaterMatrix_path13):
        xbmc.sleep(5000)
        xbmc.executebuiltin(UpdaterMatrix_13)
        xbmc.sleep(10000)
        BG.update(80, Dialog_U1, 'Εισαγωγή νέων διακομιστών του PvrStalker...')
        xbmc.sleep(10000)
        BG.update(81, Dialog_U1, 'Εισαγωγή αποθετηρίων...')
        xbmc.sleep(15000)
        BG.update(82, Dialog_U1, 'repository.Vikings - repository.diamond-k19...')

    if not exists(UpdaterMatrix_path23):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_23)
        BG.update(81, Dialog_U1, 'Εισαγωγή αποθετηρίων...')
        xbmc.sleep(5000)
        BG.update(82, Dialog_U1, 'repository.a4ksubtitles...')
        xbmc.sleep(1000)
        BG.update(82, Dialog_U1, 'repository.Magnetic...')
        xbmc.sleep(1000)
        BG.update(83, Dialog_U1, 'repository.mbebe...')
        xbmc.sleep(1000)
        BG.update(83, Dialog_U1, 'repository.ocean...')
        xbmc.sleep(1000)

    if not exists(UpdaterMatrix_path24):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_24)
        BG.update(83, Dialog_U1, 'Διόρθωση skin - Netflix.xml...')
        xbmc.sleep(5000)
        BG.update(83, Dialog_U1, 'Netflix.xml - script.extendedinfo...')
        xbmc.sleep(5000)

    if not exists(UpdaterMatrix_path31):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_31)
        BG.update(85, Dialog_U1, 'Προσθήκες-Διορθώσεις στα xml του skin ...')
        xbmc.sleep(4000)

    if not exists(UpdaterMatrix_path32):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_32)
        BG.update(86, Dialog_U1, 'repository.dirtyg...')
        xbmc.sleep(4000)

    if not exists(UpdaterMatrix_path21):
        xbmc.sleep(1000)
        xbmc.executebuiltin(UpdaterMatrix_21)
        BG.update(88, Dialog_U1, 'Εισαγωγή και διόρθωση του script.extendedinfo...')
        xbmc.sleep(5000)

    xbmc.sleep(5000)


    if skinshortcuts_version > int(setting('skinshortcutsversion')):
        if addons_repos_version > int(setting('addonsreposversion')):
            BG.update(94, Dialog_U1, 'Αναμονή λίγο ακόμη.')
            xbmc.sleep(20000)
            BG.update(95, Dialog_U1, 'Αναμονή λίγο ακόμη..')
            xbmc.sleep(10000)
            BG.update(96, Dialog_U1, 'Ενεργοποίηση πρόσθετων...')
            xbmc.sleep(10000)
            BG.update(97, Dialog_U1, 'Αναμονή λίγο ακόμη...')
            xbmc.sleep(10000)
            addonsEnable.enable_addons()
            setting_set('addonsreposversion', str(addons_repos_version))
            xbmc.sleep(5000)

            xbmc.executebuiltin(skinshortcuts_menu)
            xbmc.sleep(10000)
            BG.update(98, Dialog_U1, 'Εισαγωγή xml αρχείων του script.skinshortcuts...')
            xbmc.sleep(4000)
            set_setting()
            setting_set('skinshortcutsversion', str(skinshortcuts_version))
            set_setting()
#    dialog.notification(Dialog_U7, Dialog_U5, icon_Build, sound=False)
            BG.update(100, Dialog_U4, Dialog_U5)
            xbmc.sleep(5000)
            BG.update(100, Dialog_U4, Dialog_U5)
    
    if addons_repos_version > int(setting('addonsreposversion')):
        BG.update(94, Dialog_U1, 'Αναμονή λίγο ακόμη...')
        xbmc.sleep(10000)
        BG.update(96, Dialog_U1, 'Ενεργοποίηση πρόσθετων...')
        xbmc.sleep(10000)
        BG.update(98, Dialog_U1, 'Αναμονή λίγο ακόμη...')
        xbmc.sleep(10000)
        BG.update(99, Dialog_U1, 'Είναι σχεδόν όλα έτοιμα...')
        xbmc.sleep(5000)
        addonsEnable.enable_addons()
        setting_set('addonsreposversion', str(addons_repos_version))

    if skinshortcuts_version > int(setting('skinshortcutsversion')):
        xbmc.executebuiltin(skinshortcuts_menu)
        xbmc.sleep(10000)
        BG.update(90, Dialog_U1, 'Εισαγωγή xml αρχείων του script.skinshortcuts...')
        xbmc.sleep(4000)
        set_setting()

    setting_set('skinshortcutsversion', str(skinshortcuts_version))
    set_setting()
    BG.update(100, Dialog_U4, Dialog_U5)
    xbmc.sleep(5000)
    BG.update(100, Dialog_U4, Dialog_U5)
    BG.close()
    xbmcvfs.delete(downloader_startup_delete)


def check_addons_list():
    for addons_list in addons_list_installation:
        if not exists(addons_path + '%s' % addons_list):
            xbmc.sleep(1000)
            BG.update(28, '[B]Eγκατάσταση νέων πρόσθετων[/B]', '[COLOR lime]%s[/COLOR]' % addons_list)
            installAddon()


def check_del_dir():
    for path_list in delete_files:
        if exists(addons_path + '%s' % path_list) or exists('%s' % path_list):
            path_list = path_list.replace(UpdaterMatrix, '').replace(addons_path, '')
            BG.update(33, '[B]Διαγραφή αχρείαστων αρχείων...[/B]', path_list)
            xbmc.sleep(1000)
            del_dir()

def installAddon():
    for addon_id in addons_list_installation:
      xbmc.executebuiltin('InstallAddon(%s)' % (addon_id))
      xbmc.sleep(100)
      xbmc.executebuiltin('SendClick(11)')
      xbmc.sleep(100)


def del_dir():
    for ad in addons_data_path:
     for rr in delete_files:
       dir_list = glob.iglob(os.path.join(ad, rr))
       for path in dir_list:
           if os.path.isdir(path):
               shutil.rmtree(path)
           if os.path.isfile(path):
              os.remove(path)

def set_setting():
    ###  ScrubsV2   ###
    addon_scrubsv2       = xbmcaddon.Addon('plugin.video.scrubsv2')
    setting_scrubsv2     = addon_scrubsv2.getSetting
    setting_set_scrubsv2 = addon_scrubsv2.setSetting
    if setting_scrubsv2('subtitles')=='false':
        xbmc.sleep(1000)
        setting_set_scrubsv2('subtitles', 'true')
        BG.update(93, Dialog_U1, 'Ενεργοποίηση υποτίτλων ScrubsV2...')
        xbmc.sleep(2000)
        setting_set_scrubsv2('subtitles.lang.1', 'Greek')
        BG.update(95, Dialog_U1, 'Επιλογή κύριας γλώσσας υποτίτλων σε Ελληνικά...')
        xbmc.sleep(2000)


    ###  Atlas   ###
    addon_atlas       = xbmcaddon.Addon('plugin.video.atlas')
    setting_atlas     = addon_atlas.getSetting
    setting_set_atlas = addon_atlas.setSetting
    if not setting_atlas('movie-view')=='MyFlix':
        xbmc.sleep(1000)
        setting_set_atlas('movie-view', 'MyFlix')
        BG.update(95, Dialog_U1, 'Movie view επιλογή -MyFlix-...')
        xbmc.sleep(2000)


    ###  Homelander   ###
    addon_homelander     = xbmcaddon.Addon('plugin.video.homelander')
    setting_homelander     = addon_homelander.getSetting
    setting_set_homelander = addon_homelander.setSetting
    if setting_homelander('subtitles')=='false':
        xbmc.sleep(1000)
        setting_set_homelander('subtitles', 'true')
        BG.update(99, Dialog_U1, 'Ενεργοποίηση υποτίτλων Homelander...')
        xbmc.sleep(2000)
        setting_set_homelander('subtitles.lang.1', 'Greek')
        setting_set_homelander('subtitles.lang.2', 'English')
        BG.update(99, Dialog_U1, 'Επιλογή κύριας γλώσσας υποτίτλων σε Ελληνικά...')
        xbmc.sleep(2000)
    if setting_homelander('providers.lang')=='English':
        xbmc.sleep(1000)
        setting_set_homelander('providers.lang', 'Greek+English')
        BG.update(99, Dialog_U1, 'Επιλογή παρόχων σε Greek+English...')
        xbmc.sleep(2000)

    ###  TheMoviedb   ###
    addon_themoviedb       = xbmcaddon.Addon('plugin.video.themoviedb.helper')
    setting_themoviedb     = addon_themoviedb.getSetting
    setting_set_themoviedb = addon_themoviedb.setSetting
    if setting_themoviedb('widgets_nextpage')=='false':
        BG.update(97, Dialog_U1, 'Ενεργοποίηση next page των widgets')
        setting_set_themoviedb('widgets_nextpage', 'true')
        xbmc.sleep(3000)
        if setting_themoviedb('language')=='15' or setting_themoviedb('language')=='18':
            BG.update(99, Dialog_U1, 'Αλλαγή γλώσσας (Gr) TheMovieDb...')
            setting_set_themoviedb('language', '12')
            xbmc.sleep(3000)
            BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
            xbmc.sleep(5000)
            BG.update(100, Dialog_U4, Dialog_U5)
            xbmc.sleep(2000)
            xbmc.executebuiltin("ReloadSkin()")
        else:
            BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
            xbmc.sleep(5000)
            BG.update(100, Dialog_U4, Dialog_U5)
            xbmc.sleep(2000)
            xbmc.executebuiltin("ReloadSkin()")

    if setting_themoviedb('language')=='15' or setting_themoviedb('language')=='18':
        xbmc.sleep(1000)
        setting_set_themoviedb('language', '12')
        BG.update(99, Dialog_U1, 'Αλλαγή γλώσσας (Gr) TheMovieDb...')
        xbmc.sleep(3000)
        BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
        xbmc.sleep(5000)
        BG.update(100, Dialog_U4, Dialog_U5)
        xbmc.sleep(2000)
        xbmc.executebuiltin("ReloadSkin()")
    else:
        if skinshortcuts_version > int(setting('skinshortcutsversion')):
            xbmc.sleep(5000)
            BG.update(100, Dialog_U4, 'Θα ακολουθήσει επαναφόρτωση κελύφους')
            xbmc.sleep(8000)
            BG.update(100, Dialog_U4, Dialog_U5)
            xbmc.executebuiltin("ReloadSkin()")
Updater_Matrix()
