import os, xbmc, xbmcgui, xbmcvfs
icon ='special://home/addons/pvr.stalker/icon.png'

def greektv():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9)
    call = xbmcgui.Dialog().select('[B][COLOR=deepskyblue]                                                                           Ελληνικά[/COLOR][/B]',
['[B][COLOR=deepskyblue]                                              Πρόγραμμα [COLOR=white]Τηλεόρασης[/COLOR][/B]',
 '[B][COLOR=deepskyblue]                                            Ελληνικές [COLOR=white]Ταινίες-Σειρές[/COLOR][/B]',
 '[B][COLOR=deepskyblue]                                    Ελληνικά [COLOR=white]Αθλητικά κανάλια [COLOR=lime](Atlas)[/COLOR][/B]',
 '[B][COLOR=deepskyblue]                                    Ελληνικά [COLOR=white]Αθλητικά κανάλια [COLOR=lime](Gratis)[/COLOR][/B]',
 '[B][COLOR=deepskyblue]                                                  Ελλάδα [COLOR=white]1 IPTV[/COLOR][/B]',
 '[B][COLOR=deepskyblue]                                                  Ελλάδα [COLOR=white]2 IPTV[/COLOR][/B]',
 '[B][COLOR=deepskyblue]                                                   PVR Stalker [/COLOR][/B]',
 '[B][COLOR=deepskyblue]                                             Παγκόσμιες Λίστες [/COLOR][/B]',
 '[B][COLOR=deepskyblue]                                    Ζωντανή τηλεόραση [COLOR=white]AliveGR[/COLOR][/B]'])



    if call:
        if call < 0:
            return
        func = funcs[call-9]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
        xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/Programs_tv.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.program.autowidget/?mode=group&group=greek_movies-1642525005.7029188&refresh=&reload=",return)')


def click_3():
        xbmcgui.Dialog().notification('[B][COLOR lime]Τα [COLOR=deepskyblue]κανάλια [COLOR lime]είναι διαθέσιμα[/COLOR][/B]', '[B][COLOR lime]όταν είναι και στο site ![/COLOR][/B]', '', sound=False)
        xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/GreekChannels_A.py")')

def click_4():
    if not os.path.exists(xbmcvfs.translatePath('special://home/addons/plugin.video.gratis')):
        xbmcgui.Dialog().notification('[B][COLOR orange]Αναμονή [COLOR lime]την πρώτη φορά[/COLOR][/B]', '[B][COLOR lime]μέχρι την εγκατάσταση του πρόσθετου ![/COLOR][/B]', '', sound=False)
        xbmc.executebuiltin('InstallAddon(plugin.video.gratis)')
        xbmc.sleep(200)
        xbmc.executebuiltin('SendClick(11)')
        xbmc.sleep(12000)
        xbmcgui.Dialog().notification('[B][COLOR lime]Τα [COLOR=deepskyblue]κανάλια [COLOR lime]είναι διαθέσιμα[/COLOR][/B]', '[B][COLOR lime]όταν είναι και στο site ![/COLOR][/B]', '', sound=False)
        xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/GreekChannels.py")')
    else:
        xbmcgui.Dialog().notification('[B][COLOR lime]Τα [COLOR=deepskyblue]κανάλια [COLOR lime]είναι διαθέσιμα[/COLOR][/B]', '[B][COLOR lime]όταν είναι και στο site ![/COLOR][/B]', '', sound=False)
        xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/GreekChannels.py")')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.live.streamspro/?fanart&mode=1&name=%2a%2a%2aGreece%20IPTV%202%2a%2a%2a&url=https://raw.githubusercontent.com/MorpheusLev/IPTV/master/GreekIPTV.m3u,return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.live.streamspro/?fanart&mode=1&name=%2a%2a%2aGreece%20IPTV%202%2a%2a%2a&url=https://raw.githubusercontent.com/PrantsOP/GreekIptvChannels/main/playlistGR.m3u,return)')

def click_7():
#    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [B][COLOR orange]Πύλη [COLOR lime]1[/COLOR][/B]",'[B][COLOR white]Αν η λίστα είναι κενή, ξαναπατάμε [COLOR=orange]ZTEU Generator![/COLOR][/B]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":true}}')
    xbmc.sleep(1000)
    xbmc.executebuiltin('ActivateWindow(TVChannels)')

def click_8():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.macvod/?action=tulista&title=%5BB%5D%5BCOLOR+orange%5D%CE%A4%CF%85%CF%87%CE%B1%CE%AF%CE%BF%CF%82+%CE%B4%CE%B9%CE%B1%CE%BA%CE%BF%CE%BC%CE%B9%CF%83%CF%84%CE%AE%CF%82%5B%2FCOLOR%5D%5B%2FB%5D&url=https%3A%2F%2Fpastebin.com%2Fraw%2Fktiz5e2M&thumbnail=&plot=&extra=&page=)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.AliveGR/?action=live_tv&title=%ce%96%cf%89%ce%bd%cf%84%ce%b1%ce%bd%ce%ae%20%ce%a4%ce%b7%ce%bb%ce%b5%cf%8c%cf%81%ce%b1%cf%83%ce%b7,return)')

greektv()
