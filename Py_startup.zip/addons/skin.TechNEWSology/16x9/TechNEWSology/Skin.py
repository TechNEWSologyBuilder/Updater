import os, xbmc, xbmcgui, xbmcvfs, glob
Background_path_skin        = xbmcvfs.translatePath('special://home/addons/skin.TechNEWSology/backgrounds/DEFAULT2.jpg')
Background_path             = 'Skin.SetImage(CustomDefaultBackground.path,special://home/addons/skin.TechNEWSology/backgrounds/)'
Background_path_team        = 'Skin.SetImage(CustomDefaultBackground.path,special://home/addons/skin.TechNEWSology/backgrounds/ELLINIKES_OMADES/)'
Backgrounds_path_mono       = 'Skin.SetImage(CustomDefaultBackground.path,special://home/addons/skin.TechNEWSology/backgrounds/solidcolors/)'

Backgrounds_With_Widgets    = 'RunPlugin(plugin://plugin.program.downloader19/?url=https://github.com/TechNEWSologyBuilder/Updater/raw/main/Backgrounds_With_Widgets.zip&mode=9&name=Backgrounds With Widgets)'
Backgrounds_Without_Widgets = 'RunPlugin(plugin://plugin.program.downloader19/?url=https://github.com/TechNEWSologyBuilder/Updater/raw/main/Backgrounds_Without_Widgets.zip&mode=9&name=Backgrounds Without Widgets)'
XmlSkin_startup             = 'RunPlugin(plugin://plugin.program.downloader19/?url=https://github.com/TechNEWSologyBuilder/Updater/raw/main/XmlSkin_startup.zip&mode=9)'
skinshortcuts_menu          = 'RunPlugin(plugin://plugin.program.downloader19/?url=https://github.com/TechNEWSologyBuilder/Updater/raw/main/skinshortcuts_menu.zip&mode=9)'

Backgrounds_Build           = 'RunPlugin(plugin://plugin.program.downloader19/?url=https://github.com/TechNEWSologyBuilder/Updater/raw/main/Backgrounds_Build.zip&mode=9&name=)'
Backgrounds_Team            = 'RunPlugin(plugin://plugin.program.downloader19/?url=https://github.com/TechNEWSologyBuilder/Updater/raw/main/Backgrounds_Team.zip&mode=9&name=)'
Backgrounds_Mono            = 'RunPlugin(plugin://plugin.program.downloader19/?url=https://github.com/TechNEWSologyBuilder/Updater/raw/main/Backgrounds_Mono.zip&mode=9&name=)'
icon_Build                  = 'special://home/addons/skin.TechNEWSology/icon.png'
dp = xbmcgui.Dialog()

def skin_menu():
    funcs = (action_1, action_2, action_3, action_4, action_5, action_6, action_7, action_8)
    selection = xbmcgui.Dialog().select('[B][COLOR=orange]                                                           Ρυθμίσεις Κελύφους[/COLOR][/B]', 
['[B][COLOR=white]                                            Αλλαγή Ταπετσαρίας[/COLOR][/B]',
 '[B][COLOR=white]                                        Απενεργοποίηση Widgets[/COLOR][/B]',
 '[B][COLOR=white]                                             Επαναφορά Widgets[/COLOR][/B]',
 '[B][COLOR=white]                          Επαναφορά αρχικού μενού και ρυθμίσεων[/COLOR][/B]',
 '[B][COLOR=white]               Επαναφορά προεπιλεγμένων ρυθμίσεων του Κελύφους[/COLOR][/B]',
# '[B][COLOR=white]                                Διάταξη Λίστας (Λεπτή-Κανονική)[/COLOR][/B]',
 '[B][COLOR=white]                                          Κινούμενη Ταπετσαρία[/COLOR][/B]',
 '[B][COLOR=white]                                    Submenu (Απόκρυψη-Εμφάνιση)[/COLOR][/B]',
 '[B][COLOR=white]                                Διαμόρφωση του Κεντρικού Μενού[/COLOR][/B]'])

    if selection:
        if selection < 0:
            return 
        func = funcs[selection-8]
        return func()
    else:
        func = funcs[selection]
        return func()
    return 

def action_1():
        select = dp.select('[B][COLOR orange]Επιλογή Backgrounds:[/COLOR][/B]',
                          ['[B][COLOR white]Διάφορα[/COLOR][/B]',
                           '[B][COLOR white]Μονόχρωμα[/COLOR][/B]',
                           '[B][COLOR white]Ελληνικές Ομάδες[/COLOR][/B]'])

        if select == 0:
            if not glob.glob(xbmcvfs.translatePath('special://home/addons/skin.TechNEWSology/backgrounds/DEFAULT2.jpg')):
                xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology Build[/COLOR][/B]",'[COLOR white]Παρακαλώ περιμένετε ...[/COLOR]' , icon_Build)
                xbmc.executebuiltin(Backgrounds_Build)
            #    xbmc.executebuiltin("Action(Close)")
                xbmc.sleep(10000)
                xbmc.executebuiltin("Action(Close)")
                xbmc.executebuiltin(Background_path)
            else:
                xbmc.executebuiltin(Background_path)

        if select == 1:
            if not glob.glob(xbmcvfs.translatePath('special://home/addons/skin.TechNEWSology/backgrounds/solidcolors/black.jpg')):
                xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology Build[/COLOR][/B]",'[COLOR white]Παρακαλώ περιμένετε ...[/COLOR]' , icon_Build)
                xbmc.executebuiltin(Backgrounds_Mono)
            #    xbmc.executebuiltin("Action(Close)")
                xbmc.sleep(10000)
                xbmc.executebuiltin("Action(Close)")
                xbmc.executebuiltin(Backgrounds_path_mono)
            else:
                xbmc.executebuiltin(Backgrounds_path_mono)

        if select == 2:
            if not glob.glob(xbmcvfs.translatePath('special://home/addons/skin.TechNEWSology/backgrounds/ELLINIKES_OMADES/PANIONIOS.jpg')):
                xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology Build[/COLOR][/B]",'[COLOR white]Παρακαλώ περιμένετε ...[/COLOR]' , icon_Build)
                xbmc.executebuiltin(Backgrounds_Team)
            #    xbmc.executebuiltin("Action(Close)")
                xbmc.sleep(10000)
                xbmc.executebuiltin("Action(Close)")
                xbmc.executebuiltin(Background_path_team)
            else:
                xbmc.executebuiltin(Background_path_team)

def action_2():
    choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TechNEWSology Build[/COLOR][/B]',
                                    '[COLOR white]Με αυτή την επιλογή θα αφαιρεθούν τα widgets όλων των κατηγοριών - Αυτό θα έχει ως αποτέλεσμα μείωση κατανάλωσης της μνήμης στη συσκευή σας με όφελος γρηγορότερη εναλλαγή κατηγοριών και έναρξης του Build. [CR][CR][COLOR lime]Η διαφορά στην ταχύτητα θα είναι αισθητή !!![/COLOR][CR](Όταν το μενού αναβαθμίζεται, θα επιστρέφουν τα widgets και θα χρειάζεται να επαναλαμβάνετε την διαδικασία.)',
                                    nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Αφαίρεση Widgets[/COLOR]')

    if choice == 1: [xbmc.executebuiltin("Action(Close)"),xbmc.sleep(1000),xbmc.executebuiltin("Action(Close)"),
                     xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Αφαίρεση των widgets - Αναμονή προς ολοκλήρωση.[/COLOR]' , icon_Build),
                     xbmcvfs.delete('special://profile/addon_data/script.skinshortcuts/skin.TechNEWSology.properties'),
                     xbmcvfs.delete('special://profile/addon_data/script.skinshortcuts/skin.TechNEWSology.hash'), xbmc.sleep(1000),
                     xbmc.executebuiltin(Backgrounds_Without_Widgets), xbmc.sleep(10000), xbmc.executebuiltin("ReloadSkin"), xbmc.sleep(5000),
                     xbmcgui.Dialog().ok("[COLOR lime]Αφαιρέθηκαν τα widgets με Επιτυχία ![/COLOR]", "[COLOR white]Αν επιθυμείτε την επαναφορά των widgets αλλά και την επιλογή Background, θα μεταβείτε στο επάνω μέρος Ρυθμίσεις Κελύφους με σύμβολο το πινέλο.[COLOR white][/COLOR]")]

def action_3():
    xbmc.executebuiltin("Action(Close)")
    xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]",'[COLOR white]Προσθήκη Widgets - Αναμονή προς ολοκλήρωση.[/COLOR]' , icon_Build),
    xbmc.sleep(1000)
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin(Backgrounds_With_Widgets)
    xbmc.sleep(5000)
    xbmc.executebuiltin(skinshortcuts_menu)
    xbmc.sleep(10000)
    xbmc.executebuiltin("ReloadSkin()")

def action_4():
    xbmc.executebuiltin("Action(Close)")
    xbmcgui.Dialog().notification("[B][COLOR orange]Επαναφόρτωση του προφίλ...[/COLOR][/B]",'[COLOR white]Πάγωμα εικόνας - Αναμονή προς ολοκλήρωση.[/COLOR]' , icon_Build)
    xbmc.sleep(1000)
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin(Backgrounds_With_Widgets)
    xbmc.sleep(5000)
    xbmc.executebuiltin(XmlSkin_startup)
    xbmc.sleep(10000)
    xbmc.executebuiltin("LoadProfile(Master user)")

def action_5():
    xbmc.executebuiltin("Action(Close)")
    xbmcgui.Dialog().notification("[B][COLOR orange]Επαναφόρτωση του προφίλ...[/COLOR][/B]",'[COLOR white]Πάγωμα εικόνας - Αναμονή προς ολοκλήρωση.[/COLOR]' , icon_Build)
    xbmc.sleep(1000)
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin(Backgrounds_With_Widgets)
    xbmc.sleep(5000)
    xbmc.executebuiltin(skinshortcuts_menu)
    xbmc.sleep(10000)
    xbmc.executebuiltin("LoadProfile(Master user)")


#def action_5():
#    xbmc.executebuiltin("Action(Close)")
#    xbmc.sleep(1000)
#    xbmc.executebuiltin("Action(Close)")
#    xbmc.executebuiltin('Skin.ToggleSetting(Enable.SlimList)')
#    xbmcgui.Dialog().notification("[B][COLOR red]Πραγματοποιήθηκε[/COLOR][/B]",'[COLOR white]αλλαγή στην διάταξη της λίστας.[/COLOR]' , icon_Build)

def action_6():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(1000)
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin('Skin.ToggleSetting(Enable.AnimatedBackgrounds)')
    xbmc.executebuiltin("ReloadSkin()")

def action_7():
    xbmc.executebuiltin("Action(Close)")
    xbmc.sleep(1000)
    xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin('Skin.ToggleSetting(Enable.VisibleSubmenu)')
    xbmc.executebuiltin("ReloadSkin()")

def action_8():
    xbmc.executebuiltin('ActivateWindow(SkinSettings)')
    xbmcgui.Dialog().notification("[B][COLOR red]ΠΡΟΣΟΧΗ ![/COLOR][/B]",'[COLOR white] Μετά από κάθε αναβάθμιση στο μενού του skinshortcuts του Build, θα χάνεται οποιαδήποτε αλλαγή πραγματοποιείτε.[/COLOR]' , icon_Build)

skin_menu()
