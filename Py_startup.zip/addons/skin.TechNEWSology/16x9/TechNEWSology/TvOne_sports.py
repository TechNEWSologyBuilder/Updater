import xbmc, xbmcgui


def tvone_sports():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                              ~ TvOne All [COLOR=lime]Sports Channels~[/COLOR][/B]', 
['[B][COLOR=white]                                                         TvOne[/COLOR][/B]',
 '[B][COLOR=white]                                                       TvOne11[/COLOR][/B]',
 '[B][COLOR=white]                                                      TvOne111[/COLOR][/B]',
 '[B][COLOR=white]                                                      TvOne112[/COLOR][/B]',
 '[B][COLOR=white]                                                     TvOne1112[/COLOR][/B]',
 '[B][COLOR=white]                                                TvOne1112 Live[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-6]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone/list_channels/5/,return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone11/list_channels/8/,return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone111/list_channels/1/,return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone112,return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone1112/list_channels/1/,return)')

def click_6():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone1112/list_live/,return)')

tvone_sports()
