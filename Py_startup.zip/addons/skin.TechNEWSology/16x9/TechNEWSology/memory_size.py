import xbmc, xbmcgui
Kodi_version = float(xbmc.getInfoLabel("System.BuildVersion")[:4])

def advanced_qui_set():
    xbmc.executebuiltin("Action(Close)")
    selection = xbmcgui.Dialog().select('[COLOR orange]Caching[/COLOR]',
                                       ['[B][COLOR white]Μέγεθος Μνήμης ([COLOR lime]Buffering[COLOR white])[/COLOR][/B]',
                                        '[B][COLOR white]Επαναφορά Προεπιλογή Kodi => [COLOR orange]20MB[/COLOR][/B]'])
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.sleep(500)
    if selection >=0:

        choice = xbmcgui.Dialog().yesno('[COLOR orange]Μέγεθος Μνήμης - Caching[/COLOR]',
                                        '[COLOR white]Επιλέγουμε το μέγεθος μνήμης MB [COLOR lime](Buffering)[COLOR white] που επιθυμούμε ανάλογα με την χωρητικότητα της Ram που διαθέτει η συσκευή μας.[CR]Το Build έχει αποθηκευμένη τιμή 128ΜΒ.[CR]Αν επιθυμούμε να αλλάξουμε μέγεθος ή να επαναφέρουμε την προεπιλογή του Kodi, κάνουμε την ίδια διαδικασία.[/COLOR]',
                                        nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR lime]Συνέχεια[/COLOR][/B]')
        if choice == 1:
            if 19.9 <= Kodi_version <= 21.0:
                if selection == 0:
                    xbmc.executebuiltin("ActivateWindowAndFocus(ServiceSettings, -94, )")
                    xbmc.sleep(500)
                    xbmc.executebuiltin('SendClick(-78)')
                    xbmc.executebuiltin("Action(Stop)")

                elif selection == 1:
                    xbmc.executebuiltin("ActivateWindowAndFocus(ServiceSettings, -94, )")
                    xbmc.sleep(500)
                    xbmc.executebuiltin('SendClick(-72)')
                    xbmc.executebuiltin("Action(Stop)")
                else:
                    return
            if 21.0 <= Kodi_version <= 22.0:
                if selection == 0:
                    xbmc.executebuiltin("ActivateWindowAndFocus(ServiceSettings, -194, )")
                    xbmc.sleep(500)
                    xbmc.executebuiltin('SendClick(-178)')
                    xbmc.executebuiltin("Action(Stop)")

                elif selection == 1:
                    xbmc.executebuiltin("ActivateWindowAndFocus(ServiceSettings, -194, )")
                    xbmc.sleep(500)
                    xbmc.executebuiltin('SendClick(-172)')
                    xbmc.executebuiltin("Action(Stop)")
                else:
                    return
        else:
            return
    else:
        return

advanced_qui_set()

