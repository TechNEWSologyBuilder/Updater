import xbmc, xbmcgui


def tvone_music():
    funcs = (click_1, click_2)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                         ~ TvOne All [COLOR=lime]Music Channels~[/COLOR][/B]', 
['[B][COLOR=white]                                                         TvOne[/COLOR][/B]',
 '[B][COLOR=white]                                                     TvOne1112[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-2]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone/list_channels/3,return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone1112/list_channels/5,return)')

tvone_music()
