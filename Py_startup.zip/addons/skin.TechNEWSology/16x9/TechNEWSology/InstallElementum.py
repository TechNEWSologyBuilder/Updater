import os, xbmc, xbmcgui

def install_elementum ():
        choice = xbmcgui.Dialog().yesno('[B][COLOR red]ΠΡΟΣΟΧΗ![/COLOR][/B]', '[B][COLOR orange]                                 Πρόσθετο Torrent! [CR]               Το χρησιμοποιείτε με δική σας ευθύνη. [CR]                              Προτείνεται χρήση VPN![/COLOR][/B]',
                                        yeslabel='[B][COLOR lime]Εγκατάσταση[/COLOR][/B]', nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]')
        if choice == 1: (xbmc.executebuiltin('InstallAddon(plugin.video.elementum)'),
                         xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https://gknwizard.eu/repo/Builds/TechNEWsology/UpdaterMatrix/Settings_Elementum.zip&mode=9)'))

install_elementum ()
