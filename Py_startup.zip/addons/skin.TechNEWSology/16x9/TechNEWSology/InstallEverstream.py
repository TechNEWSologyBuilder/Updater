import os, xbmc, xbmcgui

def install_everstream():
    xbmc.executebuiltin('InstallAddon(plugin.video..everstream)')
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https://github.com/TechNEWSologyBuilder/Updater/raw/main/Settings_Everstream.zip&mode=9)'))

install_everstream()
