import os, xbmc, xbmcgui

def killkodi():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TechNEWSology Build[/COLOR][/B]', '[B][COLOR deepskyblue]    https://www.facebook.com/TechNEWSologyAddons[/COLOR][/B][CR][CR][B][COLOR red]          https://www.youtube.com/@TechNEWSology[/COLOR][/B][CR][CR]           [B][COLOR lime]Υποστήριξη για την συντήρηση του Build: [COLOR cyan]                               Revolut: https://revolut.me/techkodi[/COLOR][/B][CR][CR]  [B][COLOR lime]Το Kodi θα κλείσει άμεσα...[/COLOR][/B][CR][COLOR white]  Θέλετε να συνεχίσετε?[/COLOR]',
                                        nolabel='[B][COLOR white]Όχι[/COLOR][/B]',yeslabel='[B][COLOR white]Ναι[/COLOR][/B]')
        if choice == 1:
                       if xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.stalker')):
                           xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}')
                       os._exit(1)
killkodi()