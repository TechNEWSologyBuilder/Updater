﻿import xbmc
Kodi_version = float(xbmc.getInfoLabel("System.BuildVersion")[:4])

def videoshow():
  #  xbmc.executebuiltin("Action(Close)")
    xbmc.executebuiltin("ActivateWindowAndFocus(osdvideosettings)")
    xbmc.executebuiltin("Action(Pause)")
    xbmc.sleep(500)
    if 19.9 <= Kodi_version <= 21.0:
        if xbmc.getCondVisibility('system.platform.android'):
            xbmc.executebuiltin('SendClick(-78)')
        else:
            xbmc.executebuiltin('SendClick(-77)')
    if 21.0 <= Kodi_version <= 22.0:
        if xbmc.getCondVisibility('system.platform.android'):
            xbmc.executebuiltin('SendClick(-178)')
        else:
            xbmc.executebuiltin('SendClick(-177)')

    while xbmc.getCondVisibility("Window.IsVisible(osdvideosettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

videoshow()
