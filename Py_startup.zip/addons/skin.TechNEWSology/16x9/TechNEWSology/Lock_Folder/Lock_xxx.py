######=> TechNEWSology <=######
import xbmc, xbmcgui, xbmcaddon

icon             = 'special://home/addons/plugin.image.TechNEWSology/resources/media/HDX.png'
name_build       = '[B][COLOR orange]TechNEWSology Build[/COLOR][/B]'
addon_auto       = xbmcaddon.Addon('plugin.program.autowidget')
setting_auto     = addon_auto.getSetting
setting_set_auto = addon_auto.setSetting

def lock_folder():
    if not setting_auto('lock_folder_xxx'):
        select = xbmcgui.Dialog().yesno(name_build, '[CR][COLOR white]           Επιθυμείτε να ορίσετε κωδικό κλειδώματος[CR]                             στην κατηγορία [COLOR orange]XxX [COLOR white]?[CR][CR][COLOR orange]    Στο γρανάζι επάνω δεξιά υπάρχει διαγραφή κωδικού[CR]    σε περίπτωση που ξεχάσετε τον κωδικό που ορίσατε.[/COLOR]',
                                        nolabel='[B][COLOR orange]Όχι[/COLOR][/B]',yeslabel='[B][COLOR lime]Ναι[/COLOR][/B]')
        if select == 1:
            keyb = xbmc.Keyboard('', '[B][COLOR lime]Κωδικός Ξεκλειδώματος ...[/COLOR][/B]')
            keyb.doModal()
            if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ', '_')
                setting_set_auto('lock_folder_xxx', search)
        else:
            xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.autowidget/?group=xxx-1619961180.2509713&mode=group&refresh&reload,return)')

#    if not setting_auto('lock_folder_xxx'):
#        keyb = xbmc.Keyboard('', '[COLOR lime]Ορίστε Κωδικό Ξεκλειδώματος ...[/COLOR]')
#        keyb.doModal()
#        if (keyb.isConfirmed()):
#            search = keyb.getText().replace(' ', '_')
#            setting_set_auto('lock_folder_xxx', search)

    else:
        keyb = xbmc.Keyboard('', '[B][COLOR orange]Πληκτρολογήστε Κωδικό Ξεκλειδώματος ...[/COLOR][/B]')
        keyb.doModal()
        if (keyb.isConfirmed()):
            search = keyb.getText().replace(' ', '_')
            if setting_auto('lock_folder_xxx') == search:
                xbmc.executebuiltin('ActivateWindow(10001,plugin://plugin.program.autowidget/?group=xxx-1619961180.2509713&mode=group&refresh&reload,return)')
            else:
                xbmcgui.Dialog().notification(name_build,'[B][COLOR red]Λάθος Κωδικός![/COLOR][/B]' , icon)

lock_folder()
