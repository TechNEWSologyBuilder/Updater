######=> TechNEWSology <=######
import xbmcgui, xbmcaddon

icon             = 'special://home/addons/plugin.image.TechNEWSology/resources/media/HDX.png'
name_build       = '[B][COLOR orange]TechNEWSology Build[/COLOR][/B]'
addon_auto       = xbmcaddon.Addon('plugin.program.autowidget')
setting_auto     = addon_auto.getSetting
setting_set_auto = addon_auto.setSetting

def lock_reset():
    if setting_auto('lock_folder_xxx'):
        setting_set_auto('lock_folder_xxx', '')
        xbmcgui.Dialog().notification(name_build,'[COLOR white]Πραγματοποιήθηκε διαγραφή του κωδικού![/COLOR]' , icon)

lock_reset()
