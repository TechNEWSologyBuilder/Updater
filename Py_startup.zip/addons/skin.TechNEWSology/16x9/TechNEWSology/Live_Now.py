
import os, xbmc, xbmcgui, xbmcvfs

#Live_now        = 'RunScript(special://skin/16x9/TechNEWSology/Live_Now.py)'

def live_now():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14, click_15,
             click_16, click_17, click_18, click_19, click_20)
    call = xbmcgui.Dialog().select('[B][COLOR=lime]                                                                       Παίζει τώρα...[/COLOR][/B]',
['[B][COLOR=deepskyblue]                                Πρόγραμμα[COLOR=darkviolet] Τηλεοπτικών Μεταδόσεων[/COLOR][/B]',
 '[B][COLOR=white]                                            Live Events [COLOR=orange](SportsHD)[/COLOR][/B]',
 '[B][COLOR=deepskyblue]                            Ελληνικοί Αγώνες [COLOR=white]Daddy[COLOR=lime]Live [COLOR=orange](ATLAS)[/COLOR][/B]',
 '[B][COLOR=deepskyblue]                            Ελληνικά Αθλητικά Κανάλια [COLOR=white]Daddy[COLOR=lime]Live All[/COLOR][/B]',
 '[B][COLOR=darkviolet]                                                   BlackGhost [COLOR=lime]Live[/COLOR][/B]',
 '[B][COLOR=lime]                                        RojaDirecta.me [COLOR=orange](Sports[COLOR=white]d[COLOR=orange])[/COLOR][/B]',
 '[B][COLOR=lime]                                              LiveTV.ru [COLOR=orange](Sports[COLOR=white]d[COLOR=orange])[/COLOR][/B]',
 '[B][COLOR=white]                                                    Live [COLOR=orange](Sports[COLOR=white]d[COLOR=orange])[/COLOR][/B]',
 '[B][COLOR=darkviolet]                                                Sports Central [COLOR=lime]Live[/COLOR][/B]',
 '[B][COLOR=white]                                                   TvOne1112 Live[/COLOR][/B]',
 '[B][COLOR=lime]                                Αυτοματοποιημένες Λίστες Καναλιών[/COLOR][/B]',
 '[B][COLOR=white]                                                   [COLOR=white]Daddy[COLOR=lime]Live All[/COLOR][/B]',
 '[B][COLOR=white]                                           Livetv.sx [COLOR=orange](Apex Sports)[/COLOR][/B]',
 '[B][COLOR=white]                                             Sports Live [COLOR=orange](vStream)[/COLOR][/B]',
 '[B][COLOR=white]                                                         vStream[/COLOR][/B]',
 '[B][COLOR=lime]                                           Αναζήτηση... [COLOR=orange](The Loop)[/COLOR][/B]',
 '[B][COLOR=white]                                                        The Loop[/COLOR][/B]',
 '[B][COLOR=white]                                                      Rising Tides[/COLOR][/B]',
 '[B][COLOR=white]                                              Live [COLOR=orange](Mad Titan Sports)[/COLOR][/B]',
 '[B][COLOR=lime]                                      Αναζήτηση... [COLOR=orange](Mad Titan Sports)[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-20]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def click_1():
    xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/Programs_tv.py")')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sporthdme/?description=Football&iconimage=https%3a%2f%2fsporthd.me%2fimages%2ffootball.png&mode=events&name=%5bB%5d%5bCOLOR%20white%5dFootball%5b%2fCOLOR%5d%5b%2fB%5d&url=https%3a%2f%2fsporthd.me%2fsport%2ffootball,return)')

def click_3():
    xbmcgui.Dialog().notification('[B][COLOR lime]Οι κατηγορίες θα είναι κενές αν δεν [/COLOR][/B]', '[B][COLOR lime]υπάρχουν διαθέσιμοι [COLOR=deepskyblue]Ελληνικοί αγώνες![/COLOR][/B]', '', sound=False)
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.atlas/?description&iconimage=&mode=menu&serv_type=schedGR",return)')

def click_4():
    select = xbmcgui.Dialog().select('[COLOR deepskyblue]                                  Ελληνικά Αθλητικά Κανάλια [COLOR=white]Daddy[COLOR=lime]Live[/COLOR]',
                                    ['[B][COLOR lime]                                                        Atlas[/COLOR][/B]',
                                     '[B][COLOR lime]                                                    DaddyLive[/COLOR][/B]',
                                     '[B][COLOR lime]                                                       Gratis[/COLOR][/B]'])

    if select == 0: 
        xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/GreekChannels_A.py")')

    elif select == 1:
        if not os.path.exists(xbmcvfs.translatePath('special://home/addons/plugin.video.daddylive')):
            xbmcgui.Dialog().notification('[B][COLOR orange]Αναμονή [COLOR lime]την πρώτη φορά[/COLOR][/B]', '[B][COLOR lime]μέχρι την εγκατάσταση του πρόσθετου ![/COLOR][/B]', '', sound=False)
            xbmc.executebuiltin('InstallAddon(plugin.video.daddylive)')
            xbmc.sleep(200)
            xbmc.executebuiltin('SendClick(11)')
            xbmc.sleep(10000)
            if xbmc.getCondVisibility('System.HasAddon(plugin.video.daddylive)'):
                xbmcgui.Dialog().notification('[B][COLOR lime]Τα [COLOR=deepskyblue]κανάλια [COLOR lime]είναι διαθέσιμα[/COLOR][/B]', '[B][COLOR lime]όταν είναι και στο site ![/COLOR][/B]', '', sound=False)
                xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/GreekChannels_DaddyLive.py")')
        else:
            xbmcgui.Dialog().notification('[B][COLOR lime]Τα [COLOR=deepskyblue]κανάλια [COLOR lime]είναι διαθέσιμα[/COLOR][/B]', '[B][COLOR lime]όταν είναι και στο site ![/COLOR][/B]', '', sound=False)
            xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/GreekChannels_DaddyLive.py")')

    elif select == 2:
        if not os.path.exists(xbmcvfs.translatePath('special://home/addons/plugin.video.gratis')):
            xbmcgui.Dialog().notification('[B][COLOR orange]Αναμονή [COLOR lime]την πρώτη φορά[/COLOR][/B]', '[B][COLOR lime]μέχρι την εγκατάσταση του πρόσθετου ![/COLOR][/B]', '', sound=False)
            xbmc.executebuiltin('InstallAddon(plugin.video.gratis)')
            xbmc.sleep(200)
            xbmc.executebuiltin('SendClick(11)')
            xbmc.sleep(10000)
            if xbmc.getCondVisibility('System.HasAddon(plugin.video.gratis)'):
                xbmcgui.Dialog().notification('[B][COLOR lime]Τα [COLOR=deepskyblue]κανάλια [COLOR lime]είναι διαθέσιμα[/COLOR][/B]', '[B][COLOR lime]όταν είναι και στο site ![/COLOR][/B]', '', sound=False)
                xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/GreekChannels.py")')
        else:
            xbmcgui.Dialog().notification('[B][COLOR lime]Τα [COLOR=deepskyblue]κανάλια [COLOR lime]είναι διαθέσιμα[/COLOR][/B]', '[B][COLOR lime]όταν είναι και στο site ![/COLOR][/B]', '', sound=False)
            xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/GreekChannels.py")')

    else:
        return live_now()

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.live.streamspro/?url=https://bit.ly/3DhRWqP&mode=1",return)')

def click_6():
    if not os.path.exists(xbmcvfs.translatePath('special://home/addons/plugin.video.sportsd')):
        xbmcgui.Dialog().notification('[B][COLOR orange]Αναμονή [COLOR lime]την πρώτη φορά[/COLOR][/B]', '[B][COLOR lime]μέχρι την εγκατάσταση του πρόσθετου ![/COLOR][/B]', '', sound=False)
        xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https://github.com/TechNEWSologyBuilder/Updater/raw/main/Settings_SportsD.zip&mode=9)')
        xbmc.sleep(1000)
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sportsd/?item=title%3dRojaDirecta.me%26director%3dRojaDirecta.me%26icon%3dspecial://home/addons/plugin.video.sportsd/resources/images/roja.jpg%26url%3dlivesports%252Frojadirecta.me.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1,return)')
        xbmc.sleep(5000)
        xbmc.executebuiltin('SendClick(11)')
    else:
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sportsd/?item=title%3dRojaDirecta.me%26director%3dRojaDirecta.me%26icon%3dspecial://home/addons/plugin.video.sportsd/resources/images/roja.jpg%26url%3dlivesports%252Frojadirecta.me.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1,return)')

def click_7():
    if not os.path.exists(xbmcvfs.translatePath('special://home/addons/plugin.video.sportsd')):
        xbmcgui.Dialog().notification('[B][COLOR orange]Αναμονή [COLOR lime]την πρώτη φορά[/COLOR][/B]', '[B][COLOR lime]μέχρι την εγκατάσταση του πρόσθετου ![/COLOR][/B]', '', sound=False)
        xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https://github.com/TechNEWSologyBuilder/Updater/raw/main/Settings_SportsD.zip&mode=9)')
        xbmc.sleep(1000)
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsd/?item=title%3dLiveTV.ru%26director%3dLiveTV.ru%26icon%3dspecial://home/addons/plugin.video.sportsd/resources/images/livetv_ru.png%26url%3dlivesports%252Flivetv.ru.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1",return)')
        xbmc.sleep(5000)
        xbmc.executebuiltin('SendClick(11)')
    else:
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsd/?item=title%3dLiveTV.ru%26director%3dLiveTV.ru%26icon%3dspecial://home/addons/plugin.video.sportsd/resources/images/livetv_ru.png%26url%3dlivesports%252Flivetv.ru.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1",return)')

def click_8():
    if not os.path.exists(xbmcvfs.translatePath('special://home/addons/plugin.video.sportsd')):
        xbmcgui.Dialog().notification('[B][COLOR orange]Αναμονή [COLOR lime]την πρώτη φορά[/COLOR][/B]', '[B][COLOR lime]μέχρι την εγκατάσταση του πρόσθετου ![/COLOR][/B]', '', sound=False)
        xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https://github.com/TechNEWSologyBuilder/Updater/raw/main/Settings_SportsD.zip&mode=9)')
        xbmc.sleep(1000)
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsd/?item=title%3dLive%2bSports%26type%3drss%26genre%3dLive%2bSports%26director%3dSportsD%26icon%3dC%253A%255CUsers%255Chplap%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.sportsd%255Cresources%255Cimages%255Cicons%252Flive_sports.png%26url%3dlivesports.cfg%26definedIn%3dmainMenu.cfg&mode=1",return)')
        xbmc.sleep(5000)
        xbmc.executebuiltin('SendClick(11)')
    else:
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportsd/?item=title%3dLive%2bSports%26type%3drss%26genre%3dLive%2bSports%26director%3dSportsD%26icon%3dC%253A%255CUsers%255Chplap%255CAppData%255CRoaming%255CKodi%255Caddons%255Cplugin.video.sportsd%255Cresources%255Cimages%255Cicons%252Flive_sports.png%26url%3dlivesports.cfg%26definedIn%3dmainMenu.cfg&mode=1",return)')

def click_9():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.sportscentral/?content=video&fanart=&link=https%3a%2f%2fstreamed.su%2fapi%2fmatches%2flive&mode=get_list&page=1&thumbnail=&title=Live&type=dir",return)')

def click_10():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone1112/list_live/,return)')

def click_11():
    xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/Pvr/list.py")')

def click_12():
    select = xbmcgui.Dialog().select('[COLOR white]                                Daddy[COLOR=lime]Live [COLOR white]site στα αντίστοιχα πρόσθετα:[/COLOR]',
                                    ['[B][COLOR lime]                                                        Atlas[/COLOR][/B]',
                                     '[B][COLOR lime]                                                    DaddyLive[/COLOR][/B]',
                                     '[B][COLOR lime]                                                       Gratis[/COLOR][/B]',
                                     '[B][COLOR lime]                                                      Sportsd[/COLOR][/B]',
                                     '[B][COLOR lime]                                                      vStream[/COLOR][/B]',
                                     '[B][COLOR lime]                                                     The-Loop[/COLOR][/B]'])

    if select == 0: 
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.atlas/?description&iconimage=&mode=240&name=&url",return)')

    elif select == 1:
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.daddylive",return)')

    elif select == 2:
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.gratis/?name=Live+Sports&url=&mode=live_main",return)')

    elif select == 3:
        if not os.path.exists(xbmcvfs.translatePath('special://home/addons/plugin.video.sportsd')):
            xbmcgui.Dialog().notification('[B][COLOR orange]Αναμονή [COLOR lime]την πρώτη φορά[/COLOR][/B]', '[B][COLOR lime]μέχρι την εγκατάσταση του πρόσθετου ![/COLOR][/B]', '', sound=False)
            xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?url=https://github.com/TechNEWSologyBuilder/Updater/raw/main/Settings_SportsD.zip&mode=9)')
            xbmc.sleep(1000)
            xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sportsd/?item=title%3dDaddyLive%26director%3ddaddylivehd.sx%26icon%3dhttps%253A%252F%252Fi.imgur.com%252F8EL6mr3.png%26url%3dlivesports%252Fdaddylive.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1,return)')
            xbmc.sleep(5000)
            xbmc.executebuiltin('SendClick(11)')
        else:
            xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.sportsd/?item=title%3dDaddyLive%26director%3ddaddylivehd.sx%26icon%3dhttps%253A%252F%252Fi.imgur.com%252F8EL6mr3.png%26url%3dlivesports%252Fdaddylive.cfg%26type%3drss%26genre%3dLive%2bSports%26definedIn%3dlivesports.cfg&mode=1,return)')

    elif select == 4:
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showGenres&sFav=showGenres&site=daddyhd&siteUrl=schedule%2fschedule-generated.json&atitle=DaddyHD",return)')

    elif select == 5:
        xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/sportjetextractors/games/Daddylive?sf_options=meta%3Dlabel%253DDaddylive%26",return)')

    else:
        return live_now()

def click_13():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.apex_sports/?category=live_sport&mode=open_site&site=livetv",return)')

def click_14():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=callpluging&sFav=callpluging&site=cHome&siteUrl=SPORT_LIVE&title=Sports%20",return)')

def click_15():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.vstream/?function=showSports&sFav=showSports&site=cHome&title=Sports",return)')

def click_16():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/ls3arch3/search/*?include,return")')
    xbmcgui.Dialog().notification('[B][COLOR white]The Loop [/COLOR][/B]', '[B][COLOR lime]Αναζητήστε με λατινικούς χαρακτήρες...[/COLOR][/B]', '', sound=False)
def click_17():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.the-loop/",return)')

def click_18():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.Rising.Tides",return)')

def click_19():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/get_list/https://magnetic.website/MAD_TITAN_SPORTS/SPORTS/sports.json",return)')

def click_20():
    xbmc.executebuiltin('ActivateWindow(10025,"plugin://plugin.video.madtitansports/pvr_sport_search/search/*?include=6",return)')
    xbmcgui.Dialog().notification('[B][COLOR white]Mad Titan Sports [/COLOR][/B]', '[B][COLOR lime]Αναζητήστε με λατινικούς χαρακτήρες...[/COLOR][/B]', '', sound=False)


live_now()
