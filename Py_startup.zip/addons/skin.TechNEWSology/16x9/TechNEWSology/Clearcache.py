import xbmc

def clearcache():
    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=23)')
    xbmc.sleep(5000)
    xbmc.executebuiltin('SendClick(11)')
clearcache()
