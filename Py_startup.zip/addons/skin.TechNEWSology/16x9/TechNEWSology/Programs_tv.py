######Tk######
import urllib.request
import os, re, sys, json, time, glob, xbmc, xbmcvfs, xbmcgui, xbmcaddon, sqlite3, random, requests
from urllib.request import urlopen, Request

user_agent = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36'
icon ='https://media.cdnandroid.com/item_images/790803/imagen-greek-tv-0ori.jpg'


class Tv:
    def programs():
        dp = xbmcgui.Dialog()
        select = dp.select('[COLOR white]                                                       Πρόγραμμα Τηλεόρασης[/COLOR]',
                          ['[B][COLOR lime]                           Sport FM ([COLOR darkviolet] Σημερινές Αθλητικές Μεταδόσεις [COLOR lime])[/COLOR][/B]',
                           '[B][COLOR lime]                                                    Ελλ. Κανάλια[/COLOR][/B]',
                           '[B][COLOR lime]                                        Cosmote Tv Channels Only[/COLOR][/B]',
                           '[B][COLOR lime]                                              Nova Channels Only[/COLOR][/B]',
                           '[B][COLOR lime]                                                     Cosmote Tv [/COLOR][/B]',
                           '[B][COLOR lime]                                                            Nova[/COLOR][/B]'])

        if select   == 0: return Tv.sportfm()
        elif select == 1: url = 'https://programmatileorasis.gr/'
        elif select == 2: return Tv.cosmote()
        elif select == 3: return Tv.nova()
        elif select == 4: url = 'https://programmatileorasis.gr/otetv.php'
        elif select == 5: url = 'https://programmatileorasis.gr/nova.php'

        else:
            url = ''
            xbmcgui.Dialog().notification('[B][COLOR lime]Πρόγραμμα Τηλεόρασης[/COLOR][/B]',
                                          '[B][COLOR orange]Ακύρωση![/COLOR][/B]' , icon)
            return

        hdrs = {'Referer': url,
                'User-Agent': user_agent}
        p = requests.get(url, headers=hdrs).text
        m = re.compile('<script>data(.*?);</script>\s+.*?<td valign="top" style=.*? class="categ">(.*?)</td><.*? class="categ">(.*?)</a>.*?>🔍</span>(.*?)</span></td></tr>', re.DOTALL).findall(p)
        channels = "[B][COLOR lime]<= [COLOR orange]Πίσω[/COLOR][/B]"
        for ch, time, prog, sp in m:
            if '[18]' in ch: ch = 'ΕΡΤ1'
            if '[87]' in ch: ch = 'ΕΡΤ2'
            if '[2]' in ch: ch = 'ΑΝΤ1'
            if '[3]' in ch: ch = 'STAR'
            if '[5]' in ch: ch = 'ALPHA'
            if '[7]' in ch: ch = 'SKAI'
            if '[1]' in ch: ch = 'MEGA'
            if '[99]' in ch: ch = 'OPEN'
            if '[6]' in ch: ch = 'ΕΡΤ3'
            if '[74]' in ch: ch = 'Nickelodeon'
            if '[17]' in ch: ch = 'TV Μακεδονία'
            if '[19]' in ch: ch = 'MAD'
            if '[80]' in ch: ch = 'ΒΟΥΛΗ'
            if '[129]' in ch: ch = 'ΕΡΤ NEWS'
            if '[50]' in ch: ch = 'Al Jazeera'
            if '[58]' in ch: ch = 'Bloomberg'
            if '[81]' in ch: ch = 'CNBC'
            if '[83]' in ch: ch = 'Cosmote Cinema 1'
            if '[95]' in ch: ch = 'Cosmote Cinema 2'
            if '[96]' in ch: ch = 'Cosmote Cinema 3'
            if '[98]' in ch: ch = 'Cosmote History'
            if '[68]' in ch: ch = 'Cosmote Sport 1'
            if '[56]' in ch: ch = 'Cosmote Sport 2'
            if '[69]' in ch: ch = 'Cosmote Sport 3'
            if '[92]' in ch: ch = 'Cosmote Sport 4'
            if '[93]' in ch: ch = 'Cosmote Sport 5'
            if '[94]' in ch: ch = 'Cosmote Sport 6'
            if '[61]' in ch: ch = 'Deutsche Welle'
            if '[66]' in ch: ch = 'Euronews'
            if '[37]' in ch: ch = 'FOX'
            if '[65]' in ch: ch = 'FOXlife'
            if '[71]' in ch: ch = 'FX'
            if '[60]' in ch: ch = 'France 24 Fr'
            if '[123]' in ch: ch = 'MAD Viral'
            if '[86]' in ch: ch = 'Village Cinema'
            if '[20]' in ch: ch = 'Animal Planet'
            if '[43]' in ch: ch = 'Boomerang'
            if '[116]' in ch: ch = 'CNN'
            if '[21]' in ch: ch = 'Discovery Channel'
            if '[44]' in ch: ch = 'Disney Channel'
            if '[42]' in ch: ch = 'Disney XD'
            if '[106]' in ch: ch = 'E! Entertainment'
            if '[35]' in ch: ch = 'EuroSport1'
            if '[36]' in ch: ch = 'EuroSport2'
            if '[16]' in ch: ch = 'MTV'
            if '[114]' in ch: ch = 'MTV Hits'
            if '[113]' in ch: ch = 'MTV Live'
            if '[111]' in ch: ch = 'Mad GREEKZ'
            if '[109]' in ch: ch = 'National Geographic HD'
            if '[24]' in ch: ch = 'NovaCinema1'
            if '[25]' in ch: ch = 'NovaCinema2'
            if '[33]' in ch: ch = 'NovaCinema3'
            if '[104]' in ch: ch = 'NovaCinema4'
            if '[115]' in ch: ch = 'Novalife'
            if '[34]' in ch: ch = 'The History Channel'
            if '[23]' in ch: ch = 'Travel Channel'
            if '[27]' in ch: ch = 'NovaSports1'
            if '[28]' in ch: ch = 'NovaSports2'
            if '[29]' in ch: ch = 'NovaSports3'
            if '[30]' in ch: ch = 'NovaSports4'
            if '[31]' in ch: ch = 'NovaSports5'
            if '[125]' in ch: ch = 'NovaSports Start'
            if '[124]' in ch: ch = 'NovaSports Prime'

            ch = '[B][COLOR deepskyblue]%s [/COLOR][/B]| ' % ch
            sp = sp.replace(',', '').replace('&#039;', '').replace('&quot;', '[B][COLOR orange] * [/COLOR][/B]')
            sp = ' |[B][COLOR limegreen] %s | [/COLOR][/B]' % sp
            prog = prog.replace(',', '')
            prog = prog.replace('<a href="/s/157/%CE%A6%CE%AF%CE%BB%CE%B1+%CE%A4%CE%BF+%CE%92%CE%AC%CF%84%CF%81%CE%B1%CF%87%CF%8C+%CE%A3%CE%BF%CF%85+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/57/%CE%9A%CF%89%CE%BD%CF%83%CF%84%CE%B1%CE%BD%CF%84%CE%AF%CE%BD%CE%BF%CF%85+%CE%9A%CE%B1%CE%B9+%CE%95%CE%BB%CE%AD%CE%BD%CE%B7%CF%82+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/252/%CE%9A%CE%AC%CF%81%CE%BC%CE%B1+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/30/%CE%9F%CE%B9%CE%BA%CE%BF%CE%B3%CE%B5%CE%BD%CE%B5%CE%B9%CE%B1%CE%BA%CE%AD%CF%82+%CE%99%CF%83%CF%84%CE%BF%CF%81%CE%AF%CE%B5%CF%82+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/391/%CE%9A%CE%B5%CE%BD%CF%84%CF%81%CE%B9%CE%BA%CF%8C+%CE%94%CE%B5%CE%BB%CF%84%CE%AF%CE%BF+%CE%95%CE%B9%CE%B4%CE%AE%CF%83%CE%B5%CF%89%CE%BD">', '')
            prog = prog.replace('<a href="/s/399/%CE%9C%CE%B5%CF%83%CE%B7%CE%BC%CE%B2%CF%81%CE%B9%CE%BD%CF%8C+%CE%94%CE%B5%CE%BB%CF%84%CE%AF%CE%BF+%CE%95%CE%B9%CE%B4%CE%AE%CF%83%CE%B5%CF%89%CE%BD">', '')
            prog = prog.replace('<a href="/s/171/%CE%A6%CE%B9%CE%BB%CE%BF%CE%B4%CE%BF%CE%BE%CE%AF%CE%B5%CF%82">', '')
            prog = prog.replace('<a href="/s/174/Mega+%CE%A3%CE%B1%CE%B2%CE%B2%CE%B1%CF%84%CE%BF%CE%BA%CF%8D%CF%81%CE%B9%CE%B1%CE%BA%CE%BF">', '')
            prog = prog.replace('<a href="/s/159/%CE%9B%CE%AF%CF%84%CF%83%CE%B1.com+%28%CE%95%29">', '').replace('<a href="/s/1218/L.A.P.D.">', '')
            prog = prog.replace('<a href="/s/159/%CE%9B%CE%AF%CF%84%CF%83%CE%B1.com">', '').replace('<a href="/s/131/Baby+Looney+Tunes">', '')
            prog = prog.replace('<a href="/s/1035/%CE%95%CF%85%CF%84%CF%85%CF%87%CE%B9%CF%83%CE%BC%CE%AD%CE%BD%CE%BF%CE%B9+%CE%9C%CE%B1%CE%B6%CE%AF">', '')
            prog = prog.replace('<a href="/s/973/%CE%A3%CF%84%CE%BF+%CE%A0%CE%B1%CF%81%CE%AC+%CE%A0%CE%AD%CE%BD%CF%84%CE%B5">', '')
            prog = prog.replace('<a href="/s/17/%CE%A4%CE%BF+%CE%9A%CE%B1%CF%86%CE%AD+%CE%A4%CE%B7%CF%82+%CE%A7%CE%B1%CF%81%CE%AC%CF%82+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/176/%CE%93%CE%BB%CF%85%CE%BA%CE%AD%CF%82+%CE%91%CE%BB%CF%87%CE%B7%CE%BC%CE%B5%CE%AF%CE%B5%CF%82+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/19/%CE%95%CE%B9%CE%BA%CF%8C%CE%BD%CE%B5%CF%82">', '').replace('<a href="/s/517/%CE%97+%CE%8F%CF%81%CE%B1+%CE%97+%CE%9A%CE%B1%CE%BB%CE%AE">', '')
            prog = prog.replace('<a href="/s/77/%CE%95%CF%81%CE%B3%CE%B1%CE%B6%CF%8C%CE%BC%CE%B5%CE%BD%CE%B7+%CE%93%CF%85%CE%BD%CE%B1%CE%AF%CE%BA%CE%B1+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/77/%CE%95%CF%81%CE%B3%CE%B1%CE%B6%CF%8C%CE%BC%CE%B5%CE%BD%CE%B7+%CE%93%CF%85%CE%BD%CE%B1%CE%AF%CE%BA%CE%B1">', '')
            prog = prog.replace('<a href="/s/210/%CE%9F+%CE%9A%CF%8C%CF%83%CE%BC%CE%BF%CF%82+%CF%84%CF%89%CE%BD+%CE%A3%CF%80%CE%BF%CF%81">', '')
            prog = prog.replace('<a href="/s/75/10%CE%B7+%CE%95%CE%BD%CF%84%CE%BF%CE%BB%CE%AE+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/579/%CE%9A%CF%8C%CE%BA%CE%BA%CE%B9%CE%BD%CE%BF%CF%82+%CE%9A%CF%8D%CE%BA%CE%BB%CE%BF%CF%82+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/56/%CE%9F%CE%BD%CE%B5%CE%B9%CF%81%CE%BF%CF%80%CE%B1%CE%B3%CE%AF%CE%B4%CE%B1+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/517/%CE%97+%CE%8F%CF%81%CE%B1+%CE%97+%CE%9A%CE%B1%CE%BB%CE%AE+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/1035/%CE%95%CF%85%CF%84%CF%85%CF%87%CE%B9%CF%83%CE%BC%CE%AD%CE%BD%CE%BF%CE%B9+%CE%9C%CE%B1%CE%B6%CE%AF+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/973/%CE%A3%CF%84%CE%BF+%CE%A0%CE%B1%CF%81%CE%AC+%CE%A0%CE%AD%CE%BD%CF%84%CE%B5+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/1218/L.A.P.D.+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/557/%CE%A0%CE%AF%CF%83%CF%89+%CE%A3%CF%84%CE%BF+%CE%A3%CF%80%CE%AF%CF%84%CE%B9">', '')
            prog = prog.replace('<a href="/s/169/%CE%8A%CF%87%CE%BD%CE%B7">', '')
            prog = prog.replace('<a href="/s/160/%CE%9F+%CE%A0%CF%8C%CE%BB%CE%B5%CE%BC%CE%BF%CF%82+%CE%A4%CF%89%CE%BD+%CE%86%CF%83%CF%84%CF%81%CF%89%CE%BD+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/699/40+%CE%9A%CF%8D%CE%BC%CE%B1%CF%84%CE%B1+%28%CE%95%29">', '')
            prog = prog.replace('<a href="/s/925/%CE%95%CE%AF%CF%83%CE%B1%CE%B9+%CE%A4%CE%BF+%CE%A4%CE%B1%CE%AF%CF%81%CE%B9+%CE%9C%CE%BF%CF%85">', '')
            prog = prog.replace('<a href="/s/1085/Safe+Sex">', '')

            if ('Ολυμπιακοί'in prog or 'Ολύμπιων' in prog or 'Ραντεβού' in prog):
                prog = ',' + ch + ('[B][COLOR lime] %s [/COLOR][/B]' % time + '- ') + prog + sp
            else:
                prog = ',' + ch + ('[B][COLOR lime] %s [/COLOR][/B]' % time + '- ') + prog

            channels = channels + prog
            lista_channels = channels.split(",")

        ret = xbmcgui.Dialog().select('[B][COLOR white]Κανάλι - Ώρα - Πρόγραμμα[/COLOR][/B]', lista_channels)
        if ret == 0:
            return Tv.programs()

        else:
            return Tv.programs()

    def cosmote():
        url = 'https://programmatileorasis.gr/otetv.php'
        hdrs = {'Referer': url,
                'User-Agent': user_agent}
        p = requests.get(url, headers=hdrs).text
        m = re.compile('<script>data(.*?);</script>\s+.*?<td valign="top" style=.*? class="categ">(.*?)</td><.*? class="categ">(.*?)</a>', re.DOTALL).findall(p)
        channels = "[B][COLOR lime]<= [COLOR orange]Πίσω[/COLOR][/B]"
        for ch, time, prog in m:
            if '[83]' in ch: ch = 'Cosmote Cinema 1'
            if '[95]' in ch: ch = 'Cosmote Cinema 2'
            if '[96]' in ch: ch = 'Cosmote Cinema 3'
            if '[98]' in ch: ch = 'Cosmote History'
            if '[68]' in ch: ch = 'Cosmote Sport 1'
            if '[56]' in ch: ch = 'Cosmote Sport 2'
            if '[69]' in ch: ch = 'Cosmote Sport 3'
            if '[92]' in ch: ch = 'Cosmote Sport 4'
            if '[93]' in ch: ch = 'Cosmote Sport 5'
            if '[94]' in ch: ch = 'Cosmote Sport 6'

            ch = '[B][COLOR tomato]%s [/COLOR][/B]| ' % ch
            prog = prog.replace(',', '')

            if 'Cosmote'in ch:
                prog = ',' + ch + ('[B][COLOR lime] %s [/COLOR][/B]' % time + '- ') + prog

                channels = channels + prog
                lista_channels = channels.split(",")

        ret = xbmcgui.Dialog().select('[B][COLOR white]Κανάλι - Ώρα - Πρόγραμμα[/COLOR][/B]', lista_channels)
        if ret == 0:
            return Tv.programs()

        else:
            return Tv.programs()

    def nova():
        url = 'https://programmatileorasis.gr/nova.php'
        hdrs = {'Referer': url,
                'User-Agent': user_agent}
        p = requests.get(url, headers=hdrs).text
        m = re.compile('<script>data(.*?);</script>\s+.*?<td valign="top" style=.*? class="categ">(.*?)</td><.*? class="categ">(.*?)</a>', re.DOTALL).findall(p)
        channels = "[B][COLOR lime]<= [COLOR orange]Πίσω[/COLOR][/B]"
        for ch, time, prog in m:
            if '[24]' in ch: ch = 'NovaCinema1'
            if '[25]' in ch: ch = 'NovaCinema2'
            if '[33]' in ch: ch = 'NovaCinema3'
            if '[104]' in ch: ch = 'NovaCinema4'
            if '[115]' in ch: ch = 'Novalife'
            if '[27]' in ch: ch = 'NovaSports1'
            if '[28]' in ch: ch = 'NovaSports2'
            if '[29]' in ch: ch = 'NovaSports3'
            if '[30]' in ch: ch = 'NovaSports4'
            if '[31]' in ch: ch = 'NovaSports5'
            if '[125]' in ch: ch = 'NovaSports Start'
            if '[124]' in ch: ch = 'NovaSports Prime'

            ch = '[B][COLOR limegreen]%s [/COLOR][/B]| ' % ch
            prog = prog.replace(',', '')

            if 'Nova'in ch:
                prog = ',' + ch + ('[B][COLOR lime] %s [/COLOR][/B]' % time + '- ') + prog

                channels = channels + prog
                lista_channels = channels.split(",")

        ret = xbmcgui.Dialog().select('[B][COLOR white]Κανάλι - Ώρα - Πρόγραμμα[/COLOR][/B]', lista_channels)
        if ret == 0:
            return Tv.programs()

        else:
            return Tv.programs()

    def sportfm():
        url = 'https://www.sport-fm.gr/tv/'
        hdrs = {'Referer': url,
                'User-Agent': user_agent}
        p = requests.get(url, headers=hdrs).text
        m = re.compile('<div class="tv_logos" id=.*?>(.*?)</div>.*?<h3 class="semiblack-c zonasemibold font-size-24 minus-2 lin1">\s+(.*?)\s+</h3>.*?<p class="font-size-16">(.*?)</p>.*?<time>(.*?)</time>', re.DOTALL).findall(p)
        channels = "[B][COLOR lime]<= [COLOR orange]Πίσω[/COLOR][/B]"
        for ch, pr, prog, time in m:
            ch = '[B][COLOR darkviolet] %s [/COLOR][/B]' % ch
            prog = '[B][COLOR deepskyblue] %s [/COLOR][/B]' % prog
            time = '[B][COLOR lime] %s [/COLOR][/B]' % time
            pr = pr.replace(',', '')
            prog = ',' + time + '- ' + ch + '| ' + pr + ' |' + prog
            channels = channels + prog
            lista_channels = channels.split(",")

        ret = xbmcgui.Dialog().select('[B][COLOR white]Ώρα - Κανάλι- Πρόγραμμα[/COLOR][/B]', lista_channels)
        if ret == 0:
            return Tv.programs()

        else:
            return Tv.programs()


Tv.programs()
