import xbmc, xbmcgui, xbmcaddon

addon_pvr       = xbmcaddon.Addon('pvr.stalker')
setting_pvr     = addon_pvr.getSetting
setting_set_pvr = addon_pvr.setSetting
icon ='special://home/addons/pvr.stalker/icon.png'

def pvr():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10)

    call = xbmcgui.Dialog().select('[COLOR=lime]                                        Επιλογή Πύλης ...[/COLOR]',
['[B][COLOR=white]                                                       Πύλη [COLOR=lime]1[/COLOR][/B]',
 '[B][COLOR=white]                                                       Πύλη [COLOR=lime]2[/COLOR][/B]',
 '[B][COLOR=white]                                                       Πύλη [COLOR=lime]3[/COLOR][/B]',
 '[B][COLOR=white]                                                       Πύλη [COLOR=lime]4[/COLOR][/B]',
 '[B][COLOR=white]                                                       Πύλη [COLOR=lime]5[/COLOR][/B]',
 '[B][COLOR=white]                                                       Πύλη [COLOR=lime]6[/COLOR][/B]',
 '[B][COLOR=white]                                                       Πύλη [COLOR=lime]7[/COLOR][/B]',
 '[B][COLOR=white]                                                       Πύλη [COLOR=lime]8[/COLOR][/B]',
 '[B][COLOR=white]                                                       Πύλη [COLOR=lime]9[/COLOR][/B]',
 '[B][COLOR=white]                                                      Πύλη [COLOR=lime]10[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-10]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]1[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '0')
    pvr_on_off()
    cleaner()

def click_2():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]2[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '1')
    pvr_on_off()
    cleaner()
    xbmc.sleep(10000)
    xbmc.executebuiltin('SendClick(28)')

def click_3():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]3[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '2')
    pvr_on_off()
    cleaner()
    xbmc.sleep(10000)
    xbmc.executebuiltin('SendClick(28)')

def click_4():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]4[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '3')
    pvr_on_off()
    cleaner()
    xbmc.sleep(10000)
    xbmc.executebuiltin('SendClick(28)')

def click_5():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]5[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '4')
    pvr_on_off()
    cleaner()
    xbmc.sleep(10000)
    xbmc.executebuiltin('SendClick(28)')

def click_6():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]6[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '5')
    pvr_on_off()
    cleaner()

def click_7():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]7[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '6')
    pvr_on_off()
    cleaner()
    xbmc.sleep(10000)
    xbmc.executebuiltin('SendClick(28)')

def click_8():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]8[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '7')
    pvr_on_off()
    cleaner()
    xbmc.sleep(10000)
    xbmc.executebuiltin('SendClick(28)')

def click_9():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]9[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '8')
    pvr_on_off()
    cleaner()
    xbmc.sleep(10000)
    xbmc.executebuiltin('SendClick(28)')

def click_10():
    xbmcgui.Dialog().notification("[B][COLOR lime]Pvr Stalker[/COLOR][/B] - [COLOR orange]Πύλη [COLOR lime]10[/COLOR]",'[COLOR white]Αναμονή ολοκλήρωσης φόρτωσης καναλιών![/COLOR]' , icon)
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    setting_set_pvr('active_portal', '9')
    pvr_on_off()
    cleaner()
    xbmc.sleep(10000)
    xbmc.executebuiltin('SendClick(28)')

def cleaner():
    xbmc.executebuiltin("ActivateWindowAndFocus(pvrsettings, 100,0 , -69,0)")
    xbmc.executebuiltin('SendClick(-69)')
    xbmc.executebuiltin('SendClick(11)')
    xbmc.executebuiltin("ActivateWindow(10700)")

def pvr_on_off():
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":true}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":true}}')

pvr()
