import xbmc, xbmcgui

def install_stalker():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]PVR Stalker[/COLOR]', '[COLOR white]Πατώντας [COLOR lime]εγκατάσταση[COLOR white], το πρόσθετο θα εγκατασταθεί μόνο του και μετά από λίγο θα ανοίξει.[CR]Χρησιμοποιήστε την [COLOR lime]Αυτοματοποιημένη αντικατάσταση Mac-Url [/COLOR] ή περάστε δικές σας διευθύνσεις με την βοήθεια των Ιστότοπων Stalker Portal.[CR]Γενικά θέλει τον χρόνο του και φυσικά δεν δουλεύει τίποτα σταθερά και μόνιμα![/COLOR]',
                                        nolabel='[B][COLOR orange]Άκυρο[/COLOR][/B]',yeslabel='[B][COLOR lime]Εγκατάσταση[/COLOR][/B]')

        if choice == 1:
                       xbmc.executebuiltin('InstallAddon(pvr.stalker)')
                       xbmc.sleep(1000)
                       xbmc.executebuiltin('SendClick(11)')
                       xbmc.sleep(7000)
                       xbmc.executebuiltin('SendClick(11)')
                       xbmc.sleep(5000)
                       xbmc.executebuiltin('SendClick(11)')
                       xbmc.sleep(500)
                       xbmc.executebuiltin('ActivateWindow(TVChannels)')

install_stalker()
