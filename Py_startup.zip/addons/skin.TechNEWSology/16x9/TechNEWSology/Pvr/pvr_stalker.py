import xbmc

def pvr_stalker():
    if xbmc.getCondVisibility('System.HasAddon({})'.format('pvr.stalker')):
    #    xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader19/?mode=34)')
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":true}}')
        xbmc.sleep(5000)
        xbmc.executebuiltin('SendClick(11)')
        xbmc.sleep(100)
        xbmc.executebuiltin('ActivateWindow(TVChannels)')
pvr_stalker()
