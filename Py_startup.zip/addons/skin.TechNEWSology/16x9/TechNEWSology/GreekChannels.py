import xbmc, xbmcgui


def channels():
    funcs = (click_1, click_2, click_3, click_4, click_5, click_6, click_7, click_8, click_9, click_10, click_11, click_12, click_13, click_14,
             click_15, click_16, click_17, click_18, click_19)
    call = xbmcgui.Dialog().select('[B][COLOR=deepskyblue]                                           Ελληνικά Αθλητικά Κανάλια [COLOR=white](Gratis)[/COLOR][/B]', 
['[B][COLOR=white]                                              Cosmote Sport 1 HD[/COLOR][/B]',
 '[B][COLOR=white]                                              Cosmote Sport 2 HD[/COLOR][/B]',
 '[B][COLOR=white]                                              Cosmote Sport 3 HD[/COLOR][/B]',
 '[B][COLOR=white]                                              Cosmote Sport 4 HD[/COLOR][/B]',
 '[B][COLOR=white]                                              Cosmote Sport 5 HD[/COLOR][/B]',
 '[B][COLOR=white]                                              Cosmote Sport 6 HD[/COLOR][/B]',
 '[B][COLOR=white]                                              Cosmote Sport 7 HD[/COLOR][/B]',
 '[B][COLOR=white]                                              Cosmote Sport 8 HD[/COLOR][/B]',
 '[B][COLOR=white]                                              Cosmote Sport 9 HD[/COLOR][/B]',
 '[B][COLOR=white]                                                   Nova Sports 1 [/COLOR][/B]',
 '[B][COLOR=white]                                                   Nova Sports 2 [/COLOR][/B]',
 '[B][COLOR=white]                                                   Nova Sports 3 [/COLOR][/B]',
 '[B][COLOR=white]                                                   Nova Sports 4 [/COLOR][/B]',
 '[B][COLOR=white]                                                   Nova Sports 5 [/COLOR][/B]',
 '[B][COLOR=white]                                                   Nova Sports 6 [/COLOR][/B]',
 '[B][COLOR=white]                                      Nova Sports Premier League [/COLOR][/B]',
 '[B][COLOR=white]                                               Nova Sports Start [/COLOR][/B]',
 '[B][COLOR=white]                                               Nova Sports Prime[/COLOR][/B]',
 '[B][COLOR=white]                                               Nova Sports News[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-19]
        return func()
    else:
        func = funcs[call]
        return func()
    return 


def click_1():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-622.php&mode=live_links,return)')

def click_2():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-623.php&mode=live_links,return)')

def click_3():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-624.php&mode=live_links,return)')

def click_4():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-625.php&mode=live_links,return)')

def click_5():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-626.php&mode=live_links,return)')

def click_6():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-627.php&mode=live_links,return)')

def click_7():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-628.php&mode=live_links,return)')

def click_8():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-629.php&mode=live_links,return)')

def click_9():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-630.php&mode=live_links,return)')

def click_10():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-631.php&mode=live_links,return)')

def click_11():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-632.php&mode=live_links,return)')

def click_12():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-633.php&mode=live_links,return)')

def click_13():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-634.php&mode=live_links,return)')

def click_14():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-635.php&mode=live_links,return)')

def click_15():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-636.php&mode=live_links,return)')

def click_16():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-599.php&mode=live_links,return)')

def click_17():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-637.php&mode=live_links,return)')

def click_18():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-638.php&mode=live_links,return)')

def click_19():
    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.gratis/?url=https%3A%2F%2Fdlhd.so%2Fstream%2Fstream-639.php&mode=live_links,return)')

channels()
