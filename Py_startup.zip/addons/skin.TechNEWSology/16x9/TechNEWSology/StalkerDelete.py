import os, xbmc, xbmcgui, xbmcvfs, glob, shutil
translatePath   = xbmcvfs.translatePath

def addon_disable():
        choice = xbmcgui.Dialog().yesno('[B][COLOR orange]TechNEWSology[/COLOR][/B]', '[COLOR white]            Επιθυμείτε την διαγραφή του PVR Stalker ?[/COLOR]',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Διαγραφή[/COLOR]')

        if choice == 1: (xbmc.executebuiltin("Action(Close)"), xbmc.sleep(1000), xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}'),
                         xbmc.sleep(5000), xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid": "pvr.stalker","enabled":false}}'), xbmc.sleep(1000), stalker_del())

def stalker_del():
        base_path = translatePath('special://home/addons')
        dir_list = glob.iglob(os.path.join(base_path, "pvr.stalker"))
        for path in dir_list:
            if os.path.isdir(path):
                shutil.rmtree(path)
            if os.path.exists(base_path): xbmcgui.Dialog().notification("[B][COLOR orange]TechNEWSology[/COLOR][/B]", "[COLOR white]Το PVR Stalker αφαιρέθηκε με επιτυχία![/COLOR]", icon='special://skin/icon.png')

#        base_path = xbmc.translatePath('special://home/userdata/addon_data')
#        dir_list = glob.iglob(os.path.join(base_path, "pvr.stalker"))
#        for path in dir_list:
#            if os.path.isdir(path):
#                shutil.rmtree(path)

addon_disable()
