import xbmc, xbmcgui

if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.homelander')):
    homelander = '[B][COLOR=red]                                                     Homelander[/COLOR][/B]'
else:
    homelander = ''
if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.thecrew')):
    thecrew = '[B][COLOR=orchid]                                                        The Crew[/COLOR][/B]'
else:
    thecrew = ''
if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.absolution')):
    absolution = '[B][COLOR=red]                                                     Absolution[/COLOR][/B]'
else:
    absolution = ''
if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.releasebb')):
    releasebb = '[B][COLOR=white]                                                      Release[COLOR=orange]BB[/COLOR][/B]'
else:
    releasebb = ''

def search_movies():
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                                      Αναζήτηση Τηλ. Σειράς ... [/COLOR][/B]', 
                                  ['[B][COLOR=orange]                                                          Atlas[/COLOR][/B]',
                                   '[B][COLOR=blue]                                                    TheMovieDb[/COLOR][/B]',
                                   '[B][COLOR=white]                                                   Extended Info[/COLOR][/B]',
                                   '[B][COLOR=red]                                                     Blacklodge[/COLOR][/B]',
                                   '[B][COLOR=purple]                                                      Scrubs v2[/COLOR][/B]',
                                   '[B][COLOR=lime]                                       Elementum[COLOR=red] (Προσοχή Torrent!)[/COLOR][/B]',
                                   '[B][COLOR=violet]                                                       Thunder[/COLOR][/B]',
                                   '[B][COLOR=gray]                                                         Gratis[/COLOR][/B]',
                                   '[B][COLOR=gray]                                                         Seren[/COLOR][/B]',
                                   '[B][COLOR=white]                                                       Shadow[/COLOR][/B]',
                                   '[B][COLOR=yellow]                                                  Magic Dragon[/COLOR][/B]',
                                   '[B][COLOR=blue]                                                       Alive[COLOR=white]GR[/COLOR][/B]',
                                   '[B][COLOR=white]                                                      You[B][COLOR=red]Toube[/COLOR][/B]',
                                   homelander,
                                   thecrew,
                                   absolution,
                                   releasebb])

    if call == 0: 
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.atlas/?description&mode=4&url=new)')

    elif call == 1:
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.themoviedb.helper/?info=search&tmdb_id=None&tmdb_type=tv&widget=True)')

    elif call == 2:
        xbmc.executebuiltin('ActivateWindow(10025,plugin://script.extendedinfo/?info=search_menu)')

    elif call == 3:
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.blacklodge/?action=tvSearchnew&code)')

    elif call == 4:
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.scrubsv2/?action=tvshows_searchterm&select=tvshow)')

    elif call == 5:
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.elementum/shows/search?keyboard=1)')

    elif call == 6:
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.thethunder/?action=search_tv_shows)')

    elif call == 7:
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.gratis/?mode=bst_search)')

    elif call == 8:
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.seren/?action=showsSearch&from_widget=false)')

    elif call == 9:
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.shadow/?all_w=%7b%7d&data=%20&dates=%20&description=TMDB&eng_name=%20&episode=%20&fanart=https%3a%2f%2fsearchengineland.com%2ffigz%2fwp-content%2fseloads%2f2017%2f12%2fcompare-seo-ss-1920-800x450.jpg&fav_status=false&heb_name=%20&iconimage=C%3a%5cUsers%5chplap%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.shadow%5cresources%5cartwork%2fsearch.png&id=%20&image_master&isr=0&last_id&mode=14&name=Search&original_title=%20&search_db&season=%20&show_original_year=%20&tmdbid=%20&url=http%3a%2f%2fapi.themoviedb.org%2f3%2fsearch%2ftv%3fapi_key%3d34142515d9d23817496eeb4ff1d223d0%26query%3d%25s%26language%3del%26page%3d1&video_data=%7b%22title%22%3a%20%22Search%22%2c%20%22mediatype%22%3a%20%22movie%22%2c%20%22TVshowtitle%22%3a%20%22%22%2c%20%22season%22%3a%200%2c%20%22episode%22%3a%200%2c%20%22OriginalTitle%22%3a%20%22%20%22%2c%20%22rating%22%3a%20%220%22%2c%20%22plot%22%3a%20%22TMDB%22%2c%20%22Tag%22%3a%20%223%22%2c%20%22id%22%3a%20%22%20%22%7d)')

    elif call == 10:
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.magicdragon/?all_w=%7b%7d&data=%20&dates=%20&description=Search&eng_name=%20&episode=%20&fanart=https%3a%2f%2fsearchengineland.com%2ffigz%2fwp-content%2fseloads%2f2017%2f12%2fcompare-seo-ss-1920-800x450.jpg&fav_status=false&heb_name=%20&iconimage=C%3a%5cUsers%5chplap%5cAppData%5cRoaming%5cKodi%5caddons%5cplugin.video.magicdragon%5cresources%5cartwork%2fsearch.png&id=%20&image_master&isr=0&last_id&mode=5&mypass&name=Search&original_title=%20&search_db&season=%20&show_original_year=%20&tmdbid=%20&url=www&video_data=%7b%22title%22%3a%20%22Search%22%2c%20%22mediatype%22%3a%20%22movie%22%2c%20%22TVshowtitle%22%3a%20%22%22%2c%20%22season%22%3a%200%2c%20%22episode%22%3a%200%2c%20%22OriginalTitle%22%3a%20%22%20%22%2c%20%22rating%22%3a%20%220%22%2c%20%22plot%22%3a%20%22Search%22%2c%20%22Tag%22%3a%20%22None%22%2c%20%22id%22%3a%20%22%20%22%7d)')

    elif call == 11:
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.AliveGR/?action=search_index)')

    elif call == 12:
        xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.youtube/kodion/search/input)')

    elif call == 13:
        if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.homelander')):
            xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.homelander/?action=tvSearchnew)')

    elif call == 14:
        if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.thecrew')):
            xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.thecrew/?action=tvSearchnew)')

    elif call == 15:
        if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.absolution')):
            xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.absolution/?action=tvSearchnew)')

    elif call == 16:
        if xbmc.getCondVisibility('System.HasAddon({})'.format('plugin.video.releaseBB')):
            xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.releaseBB/?mode=search_bb&url=new)')

search_movies()