######Tk######
import os, re, sys, json, time, glob, xbmc, xbmcvfs, xbmcgui, xbmcaddon, sqlite3, random, shutil, requests
from urllib.request import urlopen, Request
from bs4 import BeautifulSoup

user_agent = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36'


def livetv_sports():
    base = 'https://livetv875.me'
    url = f'https://livetv875.me/enx/allupcomingsports/19/'
    months_num = {
        "Jan": "01", "January": "01",
        "Feb": "02", "February": "02",
        "Mar": "03", "March": "03",
        "Apr": "04", "April": "04",
        "May": "05",
        "Jun": "06", "June": "06",
        "Jul": "07", "July": "07",
        "Aug": "08", "August": "08",
        "Sep": "09", "September": "09",
        "Oct": "10", "October": "10",
        "Nov": "11", "November": "11",
        "Dec": "12", "December": "12",
    }

    session = requests.Session()
    session.headers.update({
        'User-Agent': user_agent,
        'Referer': base
    })

    try:
        html = session.get(url, timeout=5).text
    except:
        xbmcgui.Dialog().notification("LiveTV", "Failed loading page")
        return

    soup = BeautifulSoup(html, "html.parser")
    table = soup.find('table', {'class': 'main'})
    if not table:
        xbmcgui.Dialog().notification("LiveTV", "No events found")
        return

    events = table.findAll('td', {'colspan': '2', 'height': '38'})

    sname = []
    sstreams = []

    for ev in events:
        try:
            link = base + ev.find('a')['href']
            event_name = ev.find('a').getText()
            info = ev.find('span', {'class': 'evdesc'}).getText()

            # ======================
            # ΗΜΕΡΟΜΗΝΙΑ
            # ======================
            date_match = re.search(r'(\d{1,2})\s+([A-Za-z]+)', info)
            date_str = ''

            if date_match:
                day = date_match.group(1).zfill(2)
                month_en = date_match.group(2)
                month = months_num.get(month_en, '')

                if month:
                    date_str = f"{day}/{month}"

            # ======================
            # ΩΡΑ (+2 offset)
            # ======================
            time_match = re.search(r'(\d+):(\d+)', info)
            time_str = ''

            if time_match:
                hour = int(time_match.group(1))
                minute = int(time_match.group(2))

                hour = (hour + 2) % 24
                time_str = f"{hour:02d}:{minute:02d}"

            # ======================
            # ΤΕΛΙΚΟ DISPLAY
            # ======================
            if date_str:
                time_display = f"{date_str} - [COLOR cyan]{time_str}[/COLOR]"
            else:
                time_display = time_str

            # LIVE ένδειξη
            live_prefix = ''
            if 'live.gif' in str(ev):
                live_prefix = '[B][COLOR lime][LIVE] [/COLOR][/B]'

            title = f"{live_prefix}[B][COLOR orange]{time_display}[/COLOR][/B] | {event_name}"

            sname.append(title)
            sstreams.append(link)

        except:
            continue

    if not sname:
        xbmcgui.Dialog().notification("LiveTV", "No matches found")
        return


    ret = xbmcgui.Dialog().select('[COLOR lime]Επερχόμενες μεταδόσεις:[/COLOR]', sname)
    if ret >= 0:
        
        url = sstreams[ret]
        sname = []
        sstreams = []
        hdrs = {'Referer': url,
                'User-Agent': user_agent}
        p2 = requests.get(url, headers=hdrs).text
        m2 = re.compile('href="(.*?)"><img width=.*? alt="Play" src="(.*?)">').findall(p2)
        m3 = re.compile('href="(.*?)"><img OnMouseOver=.*? src="(.*?)">').findall(p2)
    #    myou = re.compile(''' OnClick="show_webplayer('youtube', '(.*?)',''').findall(p2)

    #    for link in myou:
        #    sname.append((channel))
    #        sstreams.append((link))
        for link, icon in m2:
            if 'acestream' in link:               #######  Acestream  OFF#######
                continue

            elif '/surl.lu/' in link:
                url = link
                sname = []
                sstreams = []
                hdrs = {'Referer': url,
                        'User-Agent': user_agent}
                p = requests.get(url, headers=hdrs).text
                m = re.compile('<a href="(.*?)" data-translate="to direct link">').findall(p)
                for link in m:
                    if 'youtube' in link:
                        channel= '[B]Link - [COLOR lime]YouTube[/COLOR][/B]'
                    elif 'aliez' in link:
                        channel= '[B]Link - [COLOR lime]Aliez[/COLOR][/B]'
                    else:
                        channel= '[B]Link - Web[/B]'
                    sname.append((channel))
                    sstreams.append((link))

            else:
                link = 'http:' + link
                icon = 'http:' + icon
                if 'youtube' in link:
                    channel= '[B]Link - [COLOR red]You[COLOR lime]Tube[/COLOR][/B]'
                    m = re.compile('.*?&c=(.*?)&.*?').findall(link)
                    for link in m:
                        link = link + '-Youtube'
                elif 'aliez' in link:
                    channel= '[B]Link - [COLOR lime]Aliez[/COLOR][/B]'
                else:
                    channel= '[B]Link - Web[/B]'

                sname.append((channel))
                sstreams.append((link))

        for link, icon in m3:
        #    if '/webplayer' in link:
            link = 'http:' + link
            icon = 'http:' + icon
            if 'youtube' in link:
                channel= '[B]Link - [COLOR red]You[COLOR lime]Tube[/COLOR][/B]'
                m = re.compile('.*?&c=(.*?)&.*?').findall(link)
                for link in m:
                    link = link + '-Youtube'
            elif 'aliez' in link:
                channel= '[B]Link - [COLOR lime]Aliez[/COLOR][/B]'
            else:
                channel= '[B]Link - Web[/B]'
            sname.append((channel))
            sstreams.append((link))
                
        while True:
            ret = xbmcgui.Dialog().select('[COLOR lime]Links:[/COLOR]', sname)
            if ret >= 0:
                url = sstreams[ret]
                if 'Youtube' in url:
                    url = url.replace('-Youtube', '')
                    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.youtube/play/?video_id={})'.format(url))
                else:
                    url = url.replace(':', '%3A').replace('/', '%2F').replace('=', '%3D').replace('&', '%26')
                    xbmc.executebuiltin('PlayMedia(plugin://plugin.video.apex_sports/?mode=play&url={}&title=0&img=0&category=live_sport&site=livetv&play=True)'.format(url))

                if xbmc.getCondVisibility('Window.IsActive(okdialog)'):
                    xbmc.executebuiltin('Dialog.Close(okdialog)')

                xbmc.sleep(5000)
                while xbmc.Player().isPlaying() or xbmc.getCondVisibility('Window.IsActive(busydialog)'):
                    xbmc.sleep(5000)

            else:
                return livetv_sports()


#if os.path.exists(xbmcvfs.translatePath('special://home/addons/skin.19MatrixWorld')) and os.path.exists(xbmcvfs.translatePath('special://home/addons/plugin.image.World')):
#if os.path.exists(xbmcvfs.translatePath('special://home/addons/skin.TechNEWSology')) and os.path.exists(xbmcvfs.translatePath('special://home/addons/plugin.image.TechNEWSology')):
if xbmc.getCondVisibility('System.HasAddon(resource.uisounds.technewsology)'):
    livetv_sports()