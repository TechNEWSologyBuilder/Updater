﻿import xbmc
Kodi_version = float(xbmc.getInfoLabel("System.BuildVersion")[:4])

def subsettings():
    xbmc.executebuiltin("Action(Close)")
    if 18.0 <= Kodi_version <= 19.9:
            xbmc.executebuiltin("ActivateWindowAndFocus(Playersettings, -96,)")
            xbmc.sleep(100)
            xbmc.executebuiltin("ReloadSkin")
    else:
        if 19.9 <= Kodi_version <= 21.0:
            xbmc.executebuiltin("ActivateWindowAndFocus(Playersettings, -95,)")
        if 21.0 <= Kodi_version <= 22.0:
            xbmc.executebuiltin("ActivateWindowAndFocus(Playersettings, -195,)")
    xbmc.executebuiltin("Action(Pause)")
    while xbmc.getCondVisibility("Window.IsVisible(playersettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)

    xbmc.executebuiltin("Action(Play)")

subsettings()
