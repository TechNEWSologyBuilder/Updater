﻿import xbmc
Kodi_version = float(xbmc.getInfoLabel("System.BuildVersion")[:4])

def audiosettings():
    xbmc.executebuiltin("Action(Close)")
    if 19.9 <= Kodi_version <= 21.0:
        xbmc.executebuiltin("ActivateWindowAndFocus(systemsettings, -99,)")
    if 21.0 <= Kodi_version <= 22.0:
        xbmc.executebuiltin("ActivateWindowAndFocus(systemsettings, -199,)")
    xbmc.executebuiltin("Action(Pause)")
    while xbmc.getCondVisibility("Window.IsVisible(systemsettings)") or xbmc.getCondVisibility("Window.IsVisible(dialog)"):
        xbmc.sleep(100)
    xbmc.executebuiltin("Action(Play)")

audiosettings()
