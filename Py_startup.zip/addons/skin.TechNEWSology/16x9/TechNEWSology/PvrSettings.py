import os, xbmc, xbmcvfs, xbmcgui
Dialog = xbmcgui.Dialog()


def pvrsettings():
        choice = xbmcgui.Dialog().yesno('[COLOR orange]TechNEWSology[/COLOR]', '[COLOR white]Αν για κάποιο λόγο έχουν χαθεί οι προκαθορισμένες  ρυθμίσεις του PVR Stalker, μπορούμε να κάνουμε [COLOR lime]Επαναφορά[COLOR white].[/COLOR]',
                                        nolabel='[COLOR orange]Άκυρο[/COLOR]',yeslabel='[COLOR lime]Επαναφορά[/COLOR]')

        if choice == 1: xbmcvfs.delete('special://home/addonsLeia7.zip.md5'), xbmc.executebuiltin('RunPlugin(plugin://plugin.program.downloader/service)'), xbmc.executebuiltin("Action(Close)")
        if choice == 1: xbmc.sleep(1000)
        if choice == 1: xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":7,"params":{"addonid": "pvr.stalker","enabled":false}}')

        if choice == 1: xbmcgui.Dialog().ok("[COLOR orange]TechNEWSology[/COLOR]", "[COLOR white]Περιμένουμε να ολοκληρωθεί η εισαγωγή οδηγού από πελάτες της διαχείρισης PVR.                                                          Αν δεν ξεκινήσει η διαχείριση PVR, θα χρειαστεί να κάνουμε επανεκκίνηση στο kodi.                                                  Επίσης μην ξεχάσετε να κάνετε αλλαγή Γκρουπ στην χώρα που επιθυμείτε.[/COLOR]")


pvrsettings()
