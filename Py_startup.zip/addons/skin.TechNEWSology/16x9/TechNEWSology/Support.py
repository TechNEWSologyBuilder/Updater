import xbmc, xbmcgui, webbrowser


def SitesMenu():
    funcs = (site1, site2, site3, site4, site5, site6, site7, site8, site9, site10)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                                                  TechNEWSology[/COLOR][/B]', 
['[B][COLOR=lime]                                     Δωρεά TechNEWSology Build[/COLOR][/B]',
 '[B][COLOR=orange]                                       TechNEWSology [COLOR=blue]Facebook[/COLOR][/B]',
 '[B][COLOR=orange]                                 TechNEWSology [COLOR=white]Channel [COLOR=red]YouTube[/COLOR][/B]',
 '[B][COLOR=orange]                            TechNEWSology [COLOR=white]Channel Videos [COLOR=deeppink]Odysse[/COLOR][/B]',
 '[B][COLOR=deepskyblue]                                          Πρόγραμμα [COLOR=white]Τηλεόρασης[/COLOR][/B]',
 '[B][COLOR=white]                                                     Real Debrid[/COLOR][/B]',
 '[B][COLOR=white]                                                          Trakt[/COLOR][/B]',
 '[B][COLOR=white]                                                          IMDb[/COLOR][/B]',
 '[B][COLOR=white]                                                        thetvdb[/COLOR][/B]',
 '[B][COLOR=white]                                           Ιστότοποι Υποτίτλων[/COLOR][/B]'])

    if call:
        if call < 0:
            return
        func = funcs[call-10]
        return func()
    else:
        func = funcs[call]
        return func()
    return 

def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios'):
        return 'ios'

myplatform = platform()

def site1():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.paypal.com/donate/?hosted_button_id=9BYB23J5H5XSY' ) )
    else: opensite = webbrowser . open('https://www.paypal.com/donate/?hosted_button_id=9BYB23J5H5XSY')

def site2():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.facebook.com/TechNEWSologyAddons' ) )
    else: opensite = webbrowser . open('https://www.facebook.com/TechNEWSologyAddons')

def site3():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.youtube.com/channel/UCmnxLXwsBe6hvNU-QjAA0-g' ) )
    else: opensite = webbrowser . open('https://www.youtube.com/@TechNEWSology')

def site4():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://odysee.com/@technewsology' ) )
    else: opensite = webbrowser . open('https://odysee.com/@technewsology')

def site5():
    xbmc.executebuiltin('RunScript("special://skin/16x9/TechNEWSology/Programs_tv.py")')

def site6():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://real-debrid.com' ) )
    else: opensite = webbrowser . open('https://real-debrid.com')

def site7():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://trakt.tv/auth/signin' ) )
    else: opensite = webbrowser . open('https://trakt.tv/auth/signin')

def site8():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.imdb.com/' ) )
    else: opensite = webbrowser . open('https://www.imdb.com/')

def site9():
    if myplatform == 'android': opensite = xbmc.executebuiltin( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://thetvdb.com' ) )
    else: opensite = webbrowser . open('https://thetvdb.com')

def site10():
    if myplatform == 'android': xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/SearchSubs.py)')
    else: xbmc.executebuiltin('RunScript(special://skin/16x9/TechNEWSology/SearchSubs.py)')

SitesMenu()
