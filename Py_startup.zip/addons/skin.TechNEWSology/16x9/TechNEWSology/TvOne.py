import xbmc, xbmcgui


def tvone():
    funcs = (click_1, click_2, click_3, click_4, click_5)
    call = xbmcgui.Dialog().select('[B][COLOR=orange]                                                                                ~ TvOne All ~[/COLOR][/B]', 
['[B][COLOR=white]                                                         TvOne[/COLOR][/B]',
 '[B][COLOR=white]                                                       TvOne11[/COLOR][/B]',
 '[B][COLOR=white]                                                      TvOne111[/COLOR][/B]',
 '[B][COLOR=white]                                                      TvOne112[/COLOR][/B]',
 '[B][COLOR=white]                                                     TvOne1112[/COLOR][/B]'])


    if call:
        if call < 0:
            return
        func = funcs[call-5]
        return func()
    else:
        func = funcs[call]
        return func()
    return 



def click_1():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone,return)')

def click_2():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone11,return)')

def click_3():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone111,return)')

def click_4():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone112,return)')

def click_5():
    xbmc.executebuiltin('ActivateWindow(10025,plugin://plugin.video.tvone1112,return)')

tvone()
