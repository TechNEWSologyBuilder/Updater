import xbmc
KodiVersion  = float(xbmc.getInfoLabel("System.BuildVersion")[:4])

def favourite_version():
        if KodiVersion < 21:
             xbmc.executebuiltin("ActivateWindow(Favourites)")
        else:
            xbmc.executebuiltin("ActivateWindow(favouritesbrowser)")

favourite_version()
